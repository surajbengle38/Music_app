# Manual device checklist (tick as you verify)

## Visual
- [ ] Compare each of Now Playing / Playlists / Add Song to your reference at the same width; note spacing and font differences.
- [ ] Narrow phone (360dp) and a tablet: nothing clipped; scrolling only when needed.

## Library
- [ ] Add one file of each type: MP3, WAV, FLAC, M4A/AAC, OGG. Note which fail.
- [ ] Add the same file twice: "already in your library".
- [ ] Scan a folder with subfolders; scan it again: 0 added, N already indexed.
- [ ] Cancel a scan midway; kept songs remain.
- [ ] Remove a file from the folder, rescan: song shows "(file unavailable)"; restore file, rescan: flag clears.
- [ ] Cancel the file picker: friendly message, no crash. Pick a .wma/.txt: clear "unsupported" message.
- [ ] Edit title/artist before saving; confirm the audio file's own tags are unchanged.
- [ ] Search by title and by artist; search "100%".

## Playback
- [ ] Play, pause, seek (tap + drag), previous (>3s restarts), next, track end advances.
- [ ] Shuffle, repeat off/all/one behave as labelled.
- [ ] Queue: play next, add to queue, remove current, remove others.
- [ ] Screen off, lock screen, switch apps: audio continues; notification + lock-screen controls work.
- [ ] Unplug headphones: pauses. Incoming call / other player: focus handled.
- [ ] Swipe app away while paused: service stops; while playing: continues.
- [ ] Force-stop the app, reopen: queue and position restored (paused).
- [ ] Delete a queued file, then reach it: skipped with a toast, flagged unavailable.

## Playlists / favourites / history
- [ ] Create, rename, delete (confirm), duplicate name rejected, "Favourites" rejected.
- [ ] Add songs (including a duplicate), reorder with ▲▼, remove; counts update; library unaffected.
- [ ] Double-tap artwork toggles favourite; Favourites list updates; survives restart.
- [ ] Play a song past 30s: appears in recently played once, even if you seek around.
- [ ] Upgrade test: install the Phase 3 build, add songs, then install this build over it: songs retained.

## Equalizer
- [ ] Start playback, open the sheet: bands/presets appear (or a clear "unavailable" message).
- [ ] Enable and move a band / pick a preset: audible change. Setting persists after restart.

## Offline
- [ ] Airplane mode: everything above works; no network permission prompt ever appears.
