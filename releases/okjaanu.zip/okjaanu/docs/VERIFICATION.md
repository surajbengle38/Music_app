# Acceptance status (honest)

Legend: **LOGIC-VERIFIED** compiled and run in a JVM harness. **WRITTEN** code exists, never built or run. **STATIC** confirmed by inspecting files. **INCOMPLETE** not done.

| # | Criterion | Status | Notes |
|---|-----------|--------|-------|
| 1 | Builds with the project's Gradle config | WRITTEN | Never built. Version numbers are placeholders; no wrapper included. |
| 2 | Launches without crashing | WRITTEN | |
| 3 | Three screens match the references | WRITTEN | Dimensions estimated from the screenshots; no on-device screenshot comparison done. Fonts are system fallbacks. |
| 4 | Logo unchanged | STATIC | Bundled JPEG is byte-identical to the upload (`cmp`). Shown with ContentScale.Fit. Launcher icon is the logo scaled uniformly on white. It has a white JPEG background. |
| 5 | Import individual files | WRITTEN | SAF OpenDocument + persisted permission. |
| 6 | Scan folders | WRITTEN | SAF tree walk, cancellable, progress. |
| 7 | No duplicates on rescan | WRITTEN | Unique URI index; `SongDaoTest` written, not run. |
| 8 | Metadata + embedded art | WRITTEN | MediaMetadataRetriever; mapping logic LOGIC-VERIFIED. |
| 9 | Edit metadata | WRITTEN | Title and artist, saved to our DB only. Album is not editable. |
| 10 | Real local playback | WRITTEN | Media3 ExoPlayer. Format support (MP3/WAV/FLAC/AAC/M4A/OGG) is untested on any device. |
| 11 | Controls and timestamps reflect playback | WRITTEN | State read from the player; seek math LOGIC-VERIFIED. |
| 12 | Queue operations | WRITTEN | View, play, remove, play next, add. **No queue reordering.** |
| 13 | Playlists and favourites persist | WRITTEN | Room v2 + migration; DAO/migration tests written, not run. |
| 14 | Search and history | WRITTEN | Search escaping and play-count threshold LOGIC-VERIFIED. |
| 15 | Equalizer affects audio | WRITTEN | Device-dependent; cannot be confirmed without a device. |
| 16 | Background playback + media controls | WRITTEN | MediaSessionService, foreground type mediaPlayback, notification. Untested on lock screen/other apps. |
| 17 | Works offline, no login | STATIC | No INTERNET permission and no network code in `app/src/main` (grep). |
| 18 | Errors handled gracefully | WRITTEN | Skip-and-flag on playback error, scan/permission messages. Untested failure paths. |
| 19 | Maintainable code | WRITTEN | Layered packages; manual DI. Not reviewed by a compiler or linter. |
| 20 | Windows documented honestly | STATIC | `docs/WINDOWS_PLAN.md`. |

## Tests
- JVM (`testDebugUnitTest`): TagMapperTest, PlaybackLogicTest, PlaylistLogicTest. Equivalent assertions for the pure functions passed in a harness; the JUnit classes themselves were not run.
- Device (`connectedDebugAndroidTest`): SongDaoTest, PlaylistDaoTest, MigrationTest, ScreenStructureTest. Written, not run.
- Not covered by any test: file/folder picker flows, form validation inside the view model, actual audio output, service lifecycle, notification, equalizer, visual fidelity.

## Known gaps
- No queue reordering; shuffle/repeat state is not persisted across restarts.
- Playlist thumbnails are placeholders (no artwork collage).
- Playlist "Favourites" placeholder text on Add Song is only a hint (selecting nothing = library only).
- Scanning stops if the process is killed (no background scan service).
- Missing files are flagged, never auto-deleted or relocated.
- Library root rescan uses the persisted tree permission; revoked permission shows "folder not accessible".
- Home screen has no reference design; it is my composition in the same style.
- Playback error toast is generic (does not name the song).
