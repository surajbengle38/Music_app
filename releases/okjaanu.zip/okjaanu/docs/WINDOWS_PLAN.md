# Windows implementation plan (NOT started; requires your approval of the stack)

The Android app is Android-only today. Nothing in this repository runs on Windows.

## Options
| Option | Reuse | Cost / risk |
|---|---|---|
| **A. Kotlin Multiplatform + Compose Multiplatform Desktop (recommended)** | Domain models, pure logic (tag mapping, playlist rules, play-count rule), and most Compose UI, which keeps the design lock easy to honour | Needs a refactor to extract a shared module; Android-specific pieces stay separate |
| B. Native WinUI 3 / C# | Only the design and data model | Full rewrite; best OS integration |
| C. Electron / web | Design only | Violates the stack preference; heavier |

## Plan for option A
- **UI:** Compose Multiplatform Desktop reusing the same screen composables at a phone-width window, then a resizable layout. Fonts bundled as resources.
- **Files and folders:** direct filesystem paths (`java.nio`), native folder picker (e.g. AWT/Swing or a file-dialog library), optional folder watching. No SAF equivalent is needed.
- **Metadata:** a JVM tag library (e.g. jaudiotagger) behind the same `MetadataExtractor` interface. Introduce that interface in a shared module first.
- **Playback:** the biggest decision. JavaFX Media lacks FLAC/OGG support; libVLC (via VLCJ) covers all five formats but needs VLC bundled or installed. Another path is a native engine (miniaudio/BASS) via JNI/JNA. Prototype and test all five formats before committing.
- **Windows media integration:** System Media Transport Controls (media keys, lock-screen/taskbar overlay) require WinRT interop (JNA/JNI, or a small native helper). Treat as a separate task.
- **Persistence:** Room KMP (supports desktop with bundled SQLite) or SQLDelight; keep the same schema and migrations so data models stay compatible. Store the DB under `%APPDATA%\OKJAANU`.
- **Equalizer:** no Android audio-effect API; depends on the chosen engine (VLC has an equalizer; otherwise a DSP stage).
- **Shared vs platform-specific:** shared = models, repositories' interfaces, pure logic, view models, screens. Platform = file access, metadata reader, player, session integration, packaging.
- **Packaging:** `jpackage` (Compose Desktop Gradle plugin) to MSI/EXE; code signing certificate for SmartScreen; optional auto-update.

## Prerequisites
1. Android version built and verified first.
2. A refactor to a shared module (`domain`, `data` interfaces) without changing Android behaviour.
3. Your decision on A/B/C and on the playback engine.
