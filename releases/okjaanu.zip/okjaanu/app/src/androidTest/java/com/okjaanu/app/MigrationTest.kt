package com.okjaanu.app

import android.content.Context
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.okjaanu.app.data.db.AppDatabase
import com.okjaanu.app.data.db.MIGRATION_1_2
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith

/** Builds a raw v1 database, opens it with Room + MIGRATION_1_2, and checks old data survives and Room's schema validation passes. */
@RunWith(AndroidJUnit4::class)
class MigrationTest {
    @Test fun migrate1To2KeepsSongs() = runBlocking {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        ctx.deleteDatabase("mig-test.db")
        val v1 = object : SupportSQLiteOpenHelper.Callback(1) {
            override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `songs` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `uri` TEXT NOT NULL, `title` TEXT NOT NULL, `artist` TEXT NOT NULL, `album` TEXT, `durationMs` INTEGER NOT NULL, `trackNumber` INTEGER, `artPath` TEXT, `sizeBytes` INTEGER, `isFavourite` INTEGER NOT NULL, `isAvailable` INTEGER NOT NULL, `addedAt` INTEGER NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_songs_uri` ON `songs` (`uri`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `library_roots` (`treeUri` TEXT NOT NULL, `addedAt` INTEGER NOT NULL, PRIMARY KEY(`treeUri`))")
                db.execSQL("INSERT INTO songs (uri,title,artist,durationMs,isFavourite,isAvailable,addedAt) VALUES ('u','Old','A',1000,1,1,1)")
            }
            override fun onUpgrade(db: androidx.sqlite.db.SupportSQLiteDatabase, o: Int, n: Int) {}
        }
        val helper = FrameworkSQLiteOpenHelperFactory().create(SupportSQLiteOpenHelper.Configuration.builder(ctx).name("mig-test.db").callback(v1).build())
        helper.writableDatabase.close()
        val db = Room.databaseBuilder(ctx, AppDatabase::class.java, "mig-test.db").addMigrations(MIGRATION_1_2).build()
        try {
            assertEquals(listOf("Old"), db.songDao().observeFavourites().first().map { it.title })
            assertEquals(0, db.playlistDao().observeAll().first().size)
        } finally { db.close(); ctx.deleteDatabase("mig-test.db") }
    }
}
