package com.okjaanu.app

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.okjaanu.app.data.db.*
import com.okjaanu.app.data.scan.escapeLike
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SongDaoTest {
    private lateinit var db: AppDatabase
    private lateinit var dao: SongDao
    @Before fun setUp() {
        db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext<Context>(), AppDatabase::class.java).build()
        dao = db.songDao()
    }
    @After fun tearDown() = db.close()

    private fun song(uri: String, title: String, artist: String = "A") =
        SongEntity(uri = uri, title = title, artist = artist, album = null, durationMs = 1000, trackNumber = null, artPath = null, sizeBytes = null, addedAt = 1)

    @Test fun duplicateUriIsIgnored() = runBlocking {
        assertTrue(dao.insertIgnore(song("content://x/1", "One")) > 0)
        assertEquals(-1L, dao.insertIgnore(song("content://x/1", "One again")))
        assertEquals(1, dao.observeCount().first())
    }
    @Test fun sameTitleDifferentUriIsNotADuplicate() = runBlocking {
        dao.insertIgnore(song("content://x/1", "Same")); dao.insertIgnore(song("content://x/2", "Same"))
        assertEquals(2, dao.observeCount().first())
    }
    @Test fun searchMatchesTitleAndArtistAndEscapes() = runBlocking {
        dao.insertIgnore(song("u1", "Abhi Na Jao", "Rafi")); dao.insertIgnore(song("u2", "100% Love", "Zed"))
        assertEquals(1, dao.search(escapeLike("rafi")).first().size)
        assertEquals(1, dao.search(escapeLike("100%")).first().size)
        assertEquals(0, dao.search(escapeLike("nomatch")).first().size)
    }
    @Test fun underPrefixTreatsPercentLiterally() = runBlocking {
        dao.insertIgnore(song("content://a/tree/p%3AM/document/p%3AM%2Fa.mp3", "a")); dao.insertIgnore(song("content://a/tree/other/document/b", "b"))
        assertEquals(1, dao.underPrefix("content://a/tree/p%3AM/document/").size)
    }
}
