package com.okjaanu.app

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.okjaanu.app.data.*
import com.okjaanu.app.data.db.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PlaylistDaoTest {
    private lateinit var db: AppDatabase
    private lateinit var repo: PlaylistRepository

    @Before fun setUp() {
        db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext<Context>(), AppDatabase::class.java).build()
        repo = PlaylistRepository(db)
    }
    @After fun tearDown() = db.close()

    private suspend fun song(n: Int) = db.songDao().insertIgnore(
        SongEntity(uri = "u$n", title = "T$n", artist = "A", album = null, durationMs = 1000, trackNumber = null, artPath = null, sizeBytes = null, addedAt = n.toLong()))

    @Test fun createAddDuplicateReorderRemove() = runBlocking {
        assertTrue(repo.create("Mix") is NameCheck.Valid); assertEquals(NameCheck.Taken, repo.create("mix"))
        val pid = db.playlistDao().observeAll().first().single().id
        val (a, b, c) = listOf(song(1), song(2), song(3))
        assertEquals(AddToPlaylist.Added, repo.addSong(pid, a)); repo.addSong(pid, b); repo.addSong(pid, c)
        assertEquals(AddToPlaylist.Duplicate, repo.addSong(pid, a))
        repo.move(pid, c, -2)
        assertEquals(listOf("T3", "T1", "T2"), repo.songsOf(pid).first().map { it.title })
        repo.removeSong(pid, a)
        assertEquals(2, repo.songsOf(pid).first().size)
        assertEquals(3, db.songDao().observeCount().first()) // library untouched
    }
    @Test fun deletingPlaylistKeepsSongs() = runBlocking {
        repo.create("Temp"); val pid = db.playlistDao().observeAll().first().single().id
        val s = song(1); repo.addSong(pid, s); repo.delete(pid)
        assertEquals(1, db.songDao().observeCount().first()); assertTrue(db.playlistDao().observeAll().first().isEmpty())
    }
    @Test fun favouritesSingleSourceOfTruth() = runBlocking {
        val s = song(1)
        assertEquals(true, repo.toggleFavourite(s)); assertEquals(1, repo.rows().first().first().songCount)
        assertEquals(AddToPlaylist.Duplicate, repo.addSong(FAVOURITES_ID, s))
        repo.removeSong(FAVOURITES_ID, s); assertEquals(0, repo.songsOf(FAVOURITES_ID).first().size)
    }
    @Test fun recentlyPlayedIsDistinctMostRecentFirst() = runBlocking {
        val a = song(1); val b = song(2)
        val d = db.songDao()
        d.insertHistory(HistoryEntity(songId = a, playedAt = 1)); d.insertHistory(HistoryEntity(songId = b, playedAt = 2)); d.insertHistory(HistoryEntity(songId = a, playedAt = 3))
        assertEquals(listOf("T1", "T2"), d.observeRecentlyPlayed(10).first().map { it.title })
    }
}
