package com.okjaanu.app

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import com.okjaanu.app.ui.components.BottomBar
import com.okjaanu.app.ui.components.Tab
import com.okjaanu.app.ui.screens.*
import com.okjaanu.app.ui.theme.OkJaanuTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

/** Structure/state tests for the reference screens. They check content and wiring, not pixel fidelity (that needs a human screenshot comparison). */
class ScreenStructureTest {
    @get:Rule val rule = createComposeRule()

    private val rows = listOf(PlaylistRow(1, "Favourites", 12), PlaylistRow(2, "Evening Ghazals", 8), PlaylistRow(3, "Road Trip", 21), PlaylistRow(4, "Old Is Gold", 34))

    @Test fun nowPlaying_showsReferenceElements() {
        rule.setContent { OkJaanuTheme { NowPlayingScreen(NowPlayingUi("Abhi Na Jao Choddkar", "name of the artist", null, 84_000, 245_000, false), {}, {}, {}, {}) } }
        listOf("NOW PLAYING", "Abhi Na Jao Choddkar", "name of the artist", "1:24", "4:05").forEach { rule.onNodeWithText(it).assertExists() }
        listOf("Play", "Previous track", "Next track", "Playback position").forEach { rule.onNodeWithContentDescription(it).assertExists() }
    }

    @Test fun nowPlaying_buttonReflectsPlayerState() {
        rule.setContent { OkJaanuTheme { NowPlayingScreen(NowPlayingUi("S", "A", null, 0, 1000, isPlaying = true), {}, {}, {}, {}) } }
        rule.onNodeWithContentDescription("Pause").assertExists(); rule.onNodeWithContentDescription("Play").assertDoesNotExist()
    }

    @Test fun nowPlaying_controlsInvokeCallbacks() {
        var play = 0; var prev = 0; var next = 0
        rule.setContent { OkJaanuTheme { NowPlayingScreen(NowPlayingUi("S", "A"), { play++ }, { prev++ }, { next++ }, {}) } }
        rule.onNodeWithContentDescription("Play").performScrollTo().performClick()
        rule.onNodeWithContentDescription("Previous track").performScrollTo().performClick()
        rule.onNodeWithContentDescription("Next track").performScrollTo().performClick()
        assertEquals(listOf(1, 1, 1), listOf(play, prev, next))
    }

    @Test fun nowPlaying_emptyStateHasNoFakeSong() {
        rule.setContent { OkJaanuTheme { NowPlayingScreen(NowPlayingUi(), {}, {}, {}, {}) } }
        rule.onNodeWithText("Nothing playing").assertExists(); rule.onAllNodesWithText("0:00").assertCountEquals(2)
    }

    @Test fun playlists_showsCardsCountsAndNewPlaylist() {
        var created = false
        rule.setContent { OkJaanuTheme { PlaylistsScreen(rows, NowPlayingUi("Abhi Na Jao Choddkar"), {}, { created = true }, {}, {}) } }
        listOf("PLAYLISTS", "Favourites", "12 songs", "Evening Ghazals", "8 songs", "Road Trip", "21 songs", "Old Is Gold", "34 songs", "new playlist", "current playing", "Abhi Na Jao Choddkar")
            .forEach { rule.onNodeWithText(it).assertExists() }
        rule.onNodeWithText("new playlist").performScrollTo().performClick(); assertTrue(created)
    }

    @Test fun playlists_singularSongLabel() {
        rule.setContent { OkJaanuTheme { PlaylistsScreen(listOf(PlaylistRow(9, "Solo", 1)), NowPlayingUi(), {}, {}, {}, {}) } }
        rule.onNodeWithText("1 song").assertExists()
    }

    @Test fun addSong_showsReferenceFieldsAndButton() {
        rule.setContent { OkJaanuTheme { AddSongScreen(AddSongUi(), {}, {}, {}, {}, {}) } }
        listOf("ADD SONG", "COVER ART", "choose audio file", "Song name", "e.g. Abhi Na Jao Choddkar", "Artist", "name of the artist", "Playlist", "Favourites", "ADD TO LIBRARY")
            .forEach { rule.onNodeWithText(it).assertExists() }
    }

    @Test fun addSong_showsValidationErrorAndFiresAdd() {
        var added = false
        rule.setContent { OkJaanuTheme { AddSongScreen(AddSongUi(error = "Song name can't be empty."), {}, {}, {}, {}, { added = true }) } }
        rule.onNodeWithText("Song name can't be empty.").assertExists()
        rule.onNodeWithText("ADD TO LIBRARY").performScrollTo().performClick(); assertTrue(added)
    }

    @Test fun addSong_chosenFileAndEditedFieldsAreShown() {
        rule.setContent { OkJaanuTheme { AddSongScreen(AddSongUi(title = "My Title", artist = "My Artist", chosenFileName = "x.mp3"), {}, {}, {}, {}, {}) } }
        listOf("My Title", "My Artist", "x.mp3").forEach { rule.onNodeWithText(it).assertExists() }
    }

    @Test fun home_emptyLibraryStateAndAddAction() {
        var add = false
        rule.setContent { OkJaanuTheme { HomeScreen(emptyList(), emptyList(), { _, _ -> }, { add = true }, {}, {}) } }
        rule.onNodeWithText("Your library is empty. Add songs or scan a folder to get started.").assertExists()
        rule.onNodeWithText("add music").performScrollTo().performClick(); assertTrue(add)
    }

    @Test fun home_searchShowsResultsAndNoMatchState() {
        rule.setContent { OkJaanuTheme { HomeScreen(emptyList(), emptyList(), { _, _ -> }, {}, {}, {}, query = "zzz", results = emptyList()) } }
        rule.onNodeWithText("No songs match.").assertExists()
    }

    @Test fun home_tappingSongPassesListAndIndex() {
        var got: Pair<Int, Int>? = null
        val recent = listOf(SongRow(1, "One", "A"), SongRow(2, "Two", "B"))
        rule.setContent { OkJaanuTheme { HomeScreen(recent, emptyList(), { l, i -> got = l.size to i }, {}, {}, {}) } }
        rule.onNodeWithText("Two").performScrollTo().performClick(); assertEquals(2 to 1, got)
    }

    @Test fun bottomBar_tabsAndPlusAreWired() {
        val tabs = mutableListOf<Tab>(); var plus = false
        rule.setContent { OkJaanuTheme { BottomBar(Tab.Playlists, { tabs += it }, { plus = true }) } }
        rule.onNodeWithText("Home").performClick(); rule.onNodeWithText("Playlists").performClick(); rule.onNodeWithText("Player").performClick()
        rule.onNodeWithContentDescription("Add song").performClick()
        assertEquals(listOf(Tab.Home, Tab.Playlists, Tab.Player), tabs); assertTrue(plus)
    }

    @Test fun nameDialog_showsErrorAndReturnsText() {
        var saved: String? = null
        rule.setContent { OkJaanuTheme { NameDialog("New playlist", "Mix", "You already have a playlist with that name.", { saved = it }, {}) } }
        rule.onNodeWithText("You already have a playlist with that name.").assertExists()
        rule.onNodeWithText("Save").performClick(); assertEquals("Mix", saved)
    }

    @Test fun detail_emptyPlaylistMessageAndFavouritesHaveNoReorderButtons() {
        rule.setContent { OkJaanuTheme { PlaylistDetailScreen("Favourites", listOf(SongRow(1, "One", "A")), true, {}, {}, {}, { _, _ -> }, {}, {}) } }
        rule.onNodeWithContentDescription("Move One up").assertDoesNotExist()
        rule.onNodeWithContentDescription("Remove One from favourites").assertExists()
    }
}
