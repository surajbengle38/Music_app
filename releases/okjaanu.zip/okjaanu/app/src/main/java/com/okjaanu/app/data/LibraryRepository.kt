package com.okjaanu.app.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import com.okjaanu.app.data.db.*
import com.okjaanu.app.data.scan.*
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import kotlin.coroutines.coroutineContext

sealed interface AddOutcome {
    data class Added(val id: Long) : AddOutcome
    data object Duplicate : AddOutcome
    data class Unsupported(val reason: String) : AddOutcome
}

data class FilePreview(val meta: SongMeta, val art: ByteArray?, val displayName: String)
data class ScanProgress(val visited: Int = 0, val added: Int = 0, val skipped: Int = 0, val unsupported: Int = 0)
data class ScanSummary(val progress: ScanProgress, val error: String? = null)

class LibraryRepository(
    private val context: Context,
    db: AppDatabase,
    private val io: CoroutineDispatcher = Dispatchers.IO
) {
    private val dao = db.songDao()
    private val extractor = MetadataExtractor(context)

    fun recentlyAdded(limit: Int = 20): Flow<List<SongEntity>> = dao.observeRecentlyAdded(limit)
    fun search(query: String): Flow<List<SongEntity>> = dao.search(escapeLike(query.trim()))
    /** Returns songs in the order of [ids]; ids that no longer exist are dropped. */
    suspend fun songsByIds(ids: List<Long>): List<SongEntity> = withContext(io) {
        val byId = ids.distinct().chunked(500).flatMap { dao.byIds(it) }.associateBy { it.id }
        ids.mapNotNull { byId[it] }
    }
    suspend fun markUnavailable(id: Long) = withContext(io) { dao.markUnavailable(id) }

    fun recentlyPlayed(limit: Int = 20): Flow<List<SongEntity>> = dao.observeRecentlyPlayed(limit)
    suspend fun recordPlay(songId: Long) = withContext(io) { dao.insertHistory(HistoryEntity(songId = songId, playedAt = System.currentTimeMillis())) }

    fun songCount(): Flow<Int> = dao.observeCount()
    fun rootCount(): Flow<Int> = dao.observeRootCount()

    /** Reads tags for the Add Song form without saving anything. */
    suspend fun preview(uri: Uri): Result<FilePreview> = withContext(io) {
        val name = displayName(uri)
        if (!isSupportedAudioName(name)) return@withContext Result.failure(IOException("Unsupported file type. Supported: MP3, WAV, FLAC, AAC/M4A, OGG."))
        when (val r = extractor.read(uri)) {
            is ReadResult.Failed -> Result.failure(IOException(r.reason))
            is ReadResult.Ok -> Result.success(FilePreview(TagMapper.map(r.tags, name), r.art, name))
        }
    }

    /**
     * Adds one file. Edits are saved to OUR database only; the audio file's tags are never modified.
     */
    suspend fun importUri(uri: Uri, titleOverride: String? = null, artistOverride: String? = null, persist: Boolean = true): AddOutcome =
        withContext(io) {
            if (persist) tryPersist(uri)
            val key = uri.toString()
            if (dao.idForUri(key) != null) return@withContext AddOutcome.Duplicate
            val name = displayName(uri)
            if (!isSupportedAudioName(name)) return@withContext AddOutcome.Unsupported("Unsupported file type: $name")
            when (val r = extractor.read(uri)) {
                is ReadResult.Failed -> AddOutcome.Unsupported(r.reason)
                is ReadResult.Ok -> {
                    val meta = TagMapper.map(r.tags, name)
                    if (meta.durationMs == null) return@withContext AddOutcome.Unsupported("No playable audio found in $name")
                    val entity = SongEntity(
                        uri = key,
                        title = titleOverride?.trim()?.takeIf { it.isNotEmpty() } ?: meta.title,
                        artist = artistOverride?.trim()?.takeIf { it.isNotEmpty() } ?: meta.artist,
                        album = meta.album, durationMs = meta.durationMs, trackNumber = meta.trackNumber,
                        artPath = r.art?.let { saveArt(key, it) },
                        sizeBytes = DocumentFile.fromSingleUri(context, uri)?.length()?.takeIf { it > 0 },
                        addedAt = System.currentTimeMillis()
                    )
                    val id = dao.insertIgnore(entity)
                    if (id == -1L) AddOutcome.Duplicate else AddOutcome.Added(id)
                }
            }
        }

    /**
     * Recursively scans a granted folder tree. Cancellable. Non-destructive: files that vanish are
     * flagged unavailable (and restored if they reappear); nothing is deleted.
     */
    suspend fun scanTree(treeUri: Uri, onProgress: (ScanProgress) -> Unit): ScanSummary = withContext(io) {
        tryPersist(treeUri)
        val root = DocumentFile.fromTreeUri(context, treeUri)
        if (root == null || !root.canRead()) return@withContext ScanSummary(ScanProgress(), "This folder is not accessible.")
        dao.insertRoot(LibraryRootEntity(treeUri.toString(), System.currentTimeMillis()))

        var p = ScanProgress()
        val seen = HashSet<String>()
        val stack = ArrayDeque<DocumentFile>().apply { addLast(root) }
        while (stack.isNotEmpty()) {
            coroutineContext.ensureActive()
            val dir = stack.removeLast()
            for (child in dir.listFiles()) {
                coroutineContext.ensureActive()
                if (child.isDirectory) { stack.addLast(child); continue }
                val name = child.name ?: continue
                if (!isSupportedAudioName(name)) continue
                seen += child.uri.toString()
                p = when (importUri(child.uri, persist = false)) {
                    is AddOutcome.Added -> p.copy(visited = p.visited + 1, added = p.added + 1)
                    AddOutcome.Duplicate -> p.copy(visited = p.visited + 1, skipped = p.skipped + 1)
                    is AddOutcome.Unsupported -> p.copy(visited = p.visited + 1, unsupported = p.unsupported + 1)
                }
                onProgress(p)
            }
        }
        // Reached only if the scan ran to completion (cancellation throws above).
        val existing = dao.underPrefix(treeUri.toString() + "/document/")
        existing.filter { it.uri in seen && !it.isAvailable }.map { it.id }.chunked(500).forEach { dao.setAvailable(it, true) }
        existing.filter { it.uri !in seen && it.isAvailable }.map { it.id }.chunked(500).forEach { dao.setAvailable(it, false) }
        ScanSummary(p)
    }

    suspend fun rescanAll(onProgress: (ScanProgress) -> Unit): ScanSummary {
        var total = ScanProgress(); var error: String? = null
        for (root in withContext(io) { dao.roots() }) {
            val s = scanTree(Uri.parse(root.treeUri), onProgress)
            total = ScanProgress(total.visited + s.progress.visited, total.added + s.progress.added, total.skipped + s.progress.skipped, total.unsupported + s.progress.unsupported)
            if (s.error != null) error = s.error
        }
        return ScanSummary(total, error)
    }

    private fun displayName(uri: Uri): String =
        DocumentFile.fromSingleUri(context, uri)?.name ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Unknown"

    private fun tryPersist(uri: Uri) {
        try {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: SecurityException) { // provider does not offer persistable grants; file stays usable this session only
            Log.w(TAG, "Could not persist permission for $uri", e)
        }
    }

    private fun saveArt(key: String, bytes: ByteArray): String? = try {
        val dir = File(context.filesDir, "art").apply { mkdirs() }
        val name = MessageDigest.getInstance("SHA-1").digest(key.toByteArray()).joinToString("") { "%02x".format(it) }
        File(dir, name).also { it.writeBytes(bytes) }.absolutePath
    } catch (e: IOException) {
        Log.w(TAG, "Could not save artwork", e); null
    }

    private companion object { const val TAG = "LibraryRepository" }
}
