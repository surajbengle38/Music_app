package com.okjaanu.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.okjaanu.app.OkJaanuApp
import com.okjaanu.app.playback.PlaybackUi
import com.okjaanu.app.ui.screens.SongRow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class PlaybackViewModel(app: Application) : AndroidViewModel(app) {
    private val okApp = app as OkJaanuApp
    private val player = okApp.player
    private val library = okApp.library
    val state: StateFlow<PlaybackUi> = player.state

    init { player.start() }

    /** Plays [rows] as the queue, starting at [index]. */
    fun playFrom(rows: List<SongRow>, index: Int) {
        if (index !in rows.indices) return
        viewModelScope.launch {
            val songs = library.songsByIds(rows.map { it.id })
            val start = songs.indexOfFirst { it.id == rows[index].id }.coerceAtLeast(0)
            player.playList(songs, start)
        }
    }
    fun playNext(row: SongRow) = viewModelScope.launch { library.songsByIds(listOf(row.id)).firstOrNull()?.let(player::playNext) }
    fun addToQueue(row: SongRow) = viewModelScope.launch { library.songsByIds(listOf(row.id)).firstOrNull()?.let(player::addToQueue) }

    fun togglePlayPause() = player.togglePlayPause()
    fun next() = player.next()
    fun previous() = player.previous()
    fun seek(f: Float) = player.seekToFraction(f)
    fun toggleShuffle() = player.toggleShuffle()
    fun cycleRepeat() = player.cycleRepeat()
    fun playQueueIndex(i: Int) = player.playQueueIndex(i)
    fun removeFromQueue(i: Int) = player.removeFromQueue(i)
    fun clearMessage() = player.clearMessage()
}
