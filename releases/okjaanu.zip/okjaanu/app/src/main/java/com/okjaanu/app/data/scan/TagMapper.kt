package com.okjaanu.app.data.scan

data class RawTags(val title: String?, val artist: String?, val album: String?, val duration: String?, val track: String?)
data class SongMeta(val title: String, val artist: String, val album: String?, val durationMs: Long?, val trackNumber: Int?)

const val UNKNOWN_ARTIST = "Unknown artist"

/** Pure mapping from raw tag strings to our model; no Android dependencies, so it is unit-tested on the JVM. */
object TagMapper {
    fun map(raw: RawTags, displayName: String): SongMeta {
        val fallbackTitle = displayName.substringBeforeLast('.', displayName).trim().ifEmpty { "Untitled" }
        return SongMeta(
            title = raw.title.clean() ?: fallbackTitle,
            artist = raw.artist.clean() ?: UNKNOWN_ARTIST,
            album = raw.album.clean(),
            durationMs = raw.duration?.trim()?.toLongOrNull()?.takeIf { it > 0 },
            trackNumber = raw.track?.substringBefore('/')?.trim()?.toIntOrNull()?.takeIf { it > 0 }
        )
    }

    private fun String?.clean(): String? = this?.trim()?.takeIf { it.isNotEmpty() }
}

val SUPPORTED_EXTENSIONS = setOf("mp3", "wav", "flac", "aac", "m4a", "ogg")

fun isSupportedAudioName(name: String): Boolean =
    name.substringAfterLast('.', "").lowercase() in SUPPORTED_EXTENSIONS

/** Escapes LIKE wildcards so user input such as "100%" is matched literally (ESCAPE '\'). */
fun escapeLike(q: String): String = q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
