package com.okjaanu.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.okjaanu.app.OkJaanuApp
import com.okjaanu.app.data.FAVOURITES_ID
import com.okjaanu.app.ui.components.BottomBar
import com.okjaanu.app.ui.components.Tab
import com.okjaanu.app.ui.screens.*
import com.okjaanu.app.ui.theme.OkColors

enum class Dest(val tab: Tab) { Home(Tab.Home), Playlists(Tab.Playlists), Player(Tab.Player), PlaylistDetail(Tab.Playlists), AddSong(Tab.None) }

@Composable
fun OkJaanuRoot() {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as OkJaanuApp
    val lvm: LibraryViewModel = viewModel()
    val pvm: PlaybackViewModel = viewModel()
    val plvm: PlaylistViewModel = viewModel()

    val addUi by lvm.addUi.collectAsStateWithLifecycle()
    val recent by lvm.recentlyAdded.collectAsStateWithLifecycle()
    val played by lvm.recentlyPlayed.collectAsStateWithLifecycle()
    val results by lvm.results.collectAsStateWithLifecycle()
    val query by lvm.query.collectAsStateWithLifecycle()
    val status by lvm.status.collectAsStateWithLifecycle()
    val scanning by lvm.scanning.collectAsStateWithLifecycle()
    val hasFolders by lvm.hasFolders.collectAsStateWithLifecycle()
    val pb by pvm.state.collectAsStateWithLifecycle()
    val playlistRows by plvm.rows.collectAsStateWithLifecycle()
    val plMessage by plvm.message.collectAsStateWithLifecycle()
    val eqUi by app.equalizer.state.collectAsStateWithLifecycle()
    val currentFav by remember(pb.currentId) { plvm.isFavourite(pb.currentId) }.collectAsStateWithLifecycle(false)

    var dest by rememberSaveable { mutableStateOf(Dest.Home) }
    var detailId by rememberSaveable { mutableStateOf(FAVOURITES_ID) }
    var showQueue by remember { mutableStateOf(false) }
    var showEq by remember { mutableStateOf(false) }
    var menuSong by remember { mutableStateOf<SongRow?>(null) }
    var pickerSong by remember { mutableStateOf<SongRow?>(null) }
    var pickForAdd by remember { mutableStateOf(false) }
    var showCreate by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var nameError by remember { mutableStateOf<String?>(null) }
    var askedNotif by rememberSaveable { mutableStateOf(false) }

    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { lvm.onFilePicked(it) }
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { lvm.scanFolder(it) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { /* playback works either way */ }
    // Notification permission only affects whether the media notification is visible; playback never waits on it.
    fun askNotifOnce() {
        if (!askedNotif && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askedNotif = true; notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    fun play(rows: List<SongRow>, index: Int) { askNotifOnce(); pvm.playFrom(rows, index) }

    LaunchedEffect(pb.message) { pb.message?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show(); pvm.clearMessage() } }
    LaunchedEffect(plMessage) { plMessage?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show(); plvm.clearMessage() } }
    BackHandler(enabled = dest != Dest.Home) { dest = if (dest == Dest.PlaylistDetail) Dest.Playlists else Dest.Home }

    val player = NowPlayingUi(pb.title, pb.artist, rememberArt(pb.artPath), pb.positionMs, pb.durationMs, pb.isPlaying)

    Column(Modifier.fillMaxSize().background(OkColors.Background).safeDrawingPadding()) {
        Box(Modifier.weight(1f)) {
            when (dest) {
                Dest.Home -> HomeScreen(
                    recentlyAdded = recent, recentlyPlayed = played,
                    onPlay = { rows, i -> play(rows, i) },
                    onSongMenu = { menuSong = it },
                    onAddMusic = { lvm.clearStatus(); dest = Dest.AddSong },
                    onScanFolder = { pickFolder.launch(null) },
                    onOpenPlaylists = { dest = Dest.Playlists },
                    query = query, onQuery = lvm::setQuery, results = results, status = status,
                    scanText = scanning?.let { "Scanning… ${it.visited} files, ${it.added} added" },
                    onCancelScan = lvm::cancelScan, showRescan = hasFolders && scanning == null, onRescan = lvm::rescan
                )
                Dest.Playlists -> PlaylistsScreen(
                    playlistRows, player, onOpen = { detailId = it.id; dest = Dest.PlaylistDetail },
                    onNew = { nameError = null; showCreate = true }, onPlayPause = pvm::togglePlayPause, onOpenPlayer = { dest = Dest.Player }
                )
                Dest.PlaylistDetail -> {
                    val songs by remember(detailId) { plvm.songs(detailId) }.collectAsStateWithLifecycle(emptyList())
                    val name by remember(detailId) { plvm.name(detailId) }.collectAsStateWithLifecycle("")
                    LaunchedEffect(name) { if (name == null) dest = Dest.Playlists } // playlist was deleted
                    PlaylistDetailScreen(
                        name = name.orEmpty(), songs = songs, isFavourites = detailId == FAVOURITES_ID,
                        onPlayAll = { play(songs, 0) }, onPlaySong = { play(songs, it) },
                        onRemove = { plvm.removeSong(detailId, it.id) }, onMove = { s, d -> plvm.move(detailId, s.id, d) },
                        onRename = { nameError = null; showRename = true }, onDelete = { showDelete = true }
                    )
                    if (showRename) NameDialog("Rename playlist", name.orEmpty(), nameError, { n ->
                        plvm.rename(detailId, n) { err -> nameError = err; if (err == null) showRename = false }
                    }, { showRename = false })
                    if (showDelete) ConfirmDialog("Delete \"${name.orEmpty()}\"?", "The playlist is removed. Your songs and files are not deleted.", "Delete",
                        { plvm.delete(detailId) }, { showDelete = false })
                }
                Dest.Player -> NowPlayingScreen(
                    player, pvm::togglePlayPause, pvm::previous, pvm::next, pvm::seek,
                    onOpenQueue = { showQueue = true }, onToggleFavourite = { plvm.toggleFavourite(pb.currentId) }
                )
                Dest.AddSong -> AddSongScreen(
                    addUi, onChooseFile = { pickFile.launch(arrayOf("audio/*")) },
                    onTitle = lvm::setTitle, onArtist = lvm::setArtist,
                    onPickPlaylist = { pickForAdd = true }, onAdd = lvm::addToLibrary
                )
            }
        }
        BottomBar(dest.tab, { t -> dest = Dest.values().first { it.tab == t } }, { dest = Dest.AddSong })
    }

    if (showCreate) NameDialog("New playlist", "", nameError, { n ->
        plvm.create(n) { err -> nameError = err; if (err == null) showCreate = false }
    }, { showCreate = false })
    if (showQueue) QueueSheet(pb, { showQueue = false }, pvm::toggleShuffle, pvm::cycleRepeat, pvm::playQueueIndex, pvm::removeFromQueue,
        isFavourite = currentFav, onToggleFavourite = { plvm.toggleFavourite(pb.currentId) }, onOpenEqualizer = { showQueue = false; showEq = true })
    if (showEq) EqualizerSheet(eqUi, app.equalizer::setEnabled, app.equalizer::selectPreset, app.equalizer::setBandLevel) { showEq = false }
    menuSong?.let { song ->
        SongActionsDialog(song, { menuSong = null },
            onPlay = { play(listOf(song), 0) }, onPlayNext = { askNotifOnce(); pvm.playNext(song) }, onAddToQueue = { askNotifOnce(); pvm.addToQueue(song) },
            onAddToPlaylist = { pickerSong = song }, onToggleFavourite = { plvm.toggleFavourite(song.id) })
    }
    pickerSong?.let { song -> PlaylistPickerDialog(playlistRows, allowNone = false, onPick = { r -> r?.let { plvm.addSong(it.id, song.id, it.name) } }, onDismiss = { pickerSong = null }) }
    if (pickForAdd) PlaylistPickerDialog(playlistRows, allowNone = true,
        onPick = { r -> if (r == null) lvm.setPlaylist(null, "") else lvm.setPlaylist(r.id, r.name) }, onDismiss = { pickForAdd = false })
}
