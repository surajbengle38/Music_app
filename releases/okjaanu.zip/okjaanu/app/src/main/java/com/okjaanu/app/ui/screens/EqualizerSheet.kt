package com.okjaanu.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.okjaanu.app.playback.EqUi
import com.okjaanu.app.ui.theme.OkColors
import com.okjaanu.app.ui.theme.OkFonts

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerSheet(ui: EqUi, onEnabled: (Boolean) -> Unit, onPreset: (Int) -> Unit, onBand: (Int, Int) -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = OkColors.Background) {
        Column(Modifier.padding(horizontal = 18.dp).padding(bottom = 24.dp).verticalScroll(rememberScrollState())) {
            if (!ui.available) {
                Text("The equalizer isn't active. It attaches to the audio engine once a song has started playing, and it isn't supported on every device.",
                    color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontSize = 14.sp)
                return@Column
            }
            Box(Modifier.fillMaxWidth().height(48.dp).background(if (ui.enabled) OkColors.Accent else OkColors.Burgundy).clickable { onEnabled(!ui.enabled) }, Alignment.Center) {
                Text("equalizer: ${if (ui.enabled) "on" else "off"}", color = OkColors.Background, fontFamily = OkFonts.Body, fontSize = 14.sp, letterSpacing = 1.sp)
            }
            if (ui.presets.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                Text("presets", color = OkColors.Burgundy, fontFamily = OkFonts.Serif, fontStyle = OkFonts.SerifItalic, fontSize = 15.sp)
                Spacer(Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(ui.presets) { i, name ->
                        Box(Modifier.height(44.dp).background(if (i == ui.preset) OkColors.Accent else OkColors.Panel).clickable { onPreset(i) }.padding(horizontal = 16.dp), Alignment.Center) {
                            Text(name, color = if (i == ui.preset) OkColors.Background else OkColors.Ink, fontFamily = OkFonts.Body, fontSize = 13.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            ui.bandHz.forEachIndexed { i, hz ->
                val level = ui.levels.getOrElse(i) { 0 }
                Text("${if (hz >= 1000) "${hz / 1000} kHz" else "$hz Hz"}   ${"%+.1f".format(level / 100f)} dB", color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontSize = 13.sp)
                Slider(
                    value = level.toFloat(), onValueChange = { onBand(i, it.toInt()) },
                    valueRange = ui.minLevel.toFloat()..ui.maxLevel.toFloat(),
                    modifier = Modifier.semantics { contentDescription = "$hz hertz band" },
                    colors = SliderDefaults.colors(thumbColor = OkColors.Accent, activeTrackColor = OkColors.Burgundy, inactiveTrackColor = OkColors.Panel)
                )
            }
        }
    }
}
