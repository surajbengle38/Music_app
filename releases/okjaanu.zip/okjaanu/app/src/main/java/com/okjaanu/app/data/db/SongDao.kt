package com.okjaanu.app.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SongDao {
    /** Returns -1 when a row with the same uri already exists (unique index). */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(song: SongEntity): Long

    @Query("SELECT id FROM songs WHERE uri = :uri")
    suspend fun idForUri(uri: String): Long?

    @Query("SELECT * FROM songs ORDER BY addedAt DESC, id DESC LIMIT :limit")
    fun observeRecentlyAdded(limit: Int): Flow<List<SongEntity>>

    // :q must already be LIKE-escaped with backslash (see escapeLike).
    @Query(
        "SELECT * FROM songs WHERE title LIKE '%' || :q || '%' ESCAPE '\\' " +
            "OR artist LIKE '%' || :q || '%' ESCAPE '\\' ORDER BY title COLLATE NOCASE LIMIT 200"
    )
    fun search(q: String): Flow<List<SongEntity>>

    // substr compare instead of LIKE: URIs contain '%' which LIKE treats as a wildcard.
    @Query("SELECT * FROM songs WHERE substr(uri, 1, length(:prefix)) = :prefix")
    suspend fun underPrefix(prefix: String): List<SongEntity>

    @Query("UPDATE songs SET isAvailable = :available WHERE id IN (:ids)")
    suspend fun setAvailable(ids: List<Long>, available: Boolean)

    @Query("SELECT * FROM songs WHERE id IN (:ids)")
    suspend fun byIds(ids: List<Long>): List<SongEntity>

    @Query("UPDATE songs SET isAvailable = 0 WHERE id = :id")
    suspend fun markUnavailable(id: Long)

    // ---- favourites: the single source of truth is songs.isFavourite ----
    @Query("UPDATE songs SET isFavourite = :fav WHERE id = :id")
    suspend fun setFavourite(id: Long, fav: Boolean)

    @Query("SELECT isFavourite FROM songs WHERE id = :id")
    suspend fun isFavouriteNow(id: Long): Boolean?

    @Query("SELECT isFavourite FROM songs WHERE id = :id")
    fun observeFavourite(id: Long): Flow<Boolean?>

    @Query("SELECT * FROM songs WHERE isFavourite = 1 ORDER BY title COLLATE NOCASE")
    fun observeFavourites(): Flow<List<SongEntity>>

    @Query("SELECT COUNT(*) FROM songs WHERE isFavourite = 1")
    fun observeFavouriteCount(): Flow<Int>

    // ---- history ----
    @Insert
    suspend fun insertHistory(h: HistoryEntity)

    @Query("SELECT s.* FROM songs s INNER JOIN (SELECT songId, MAX(playedAt) AS lastPlayed FROM history GROUP BY songId) h ON h.songId = s.id ORDER BY h.lastPlayed DESC LIMIT :limit")
    fun observeRecentlyPlayed(limit: Int): Flow<List<SongEntity>>

    @Query("SELECT COUNT(*) FROM songs")
    fun observeCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertRoot(root: LibraryRootEntity)

    @Query("SELECT * FROM library_roots")
    suspend fun roots(): List<LibraryRootEntity>

    @Query("SELECT COUNT(*) FROM library_roots")
    fun observeRootCount(): Flow<Int>
}
