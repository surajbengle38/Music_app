package com.okjaanu.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.composed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.okjaanu.app.ui.theme.OkColors
import com.okjaanu.app.ui.theme.OkFonts

@Composable
fun NameDialog(title: String, initial: String, error: String?, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = OkColors.Background,
        title = { Text(title, color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontWeight = FontWeight.Bold, fontSize = 17.sp) },
        text = {
            Column {
                Box(Modifier.fillMaxWidth().height(48.dp).background(OkColors.Panel).padding(horizontal = 16.dp), Alignment.CenterStart) {
                    if (text.isEmpty()) Text("playlist name", color = OkColors.Hint, fontFamily = OkFonts.Body, fontSize = 17.sp)
                    BasicTextField(text, { text = it }, Modifier.fillMaxWidth(), singleLine = true, cursorBrush = SolidColor(OkColors.Burgundy),
                        textStyle = TextStyle(color = OkColors.Ink, fontFamily = OkFonts.Body, fontSize = 17.sp))
                }
                error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontSize = 13.sp) }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(text) }) { Text("Save", color = OkColors.Burgundy) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = OkColors.Burgundy) } }
    )
}

@Composable
fun ConfirmDialog(title: String, body: String, confirmLabel: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = OkColors.Background,
        title = { Text(title, color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontWeight = FontWeight.Bold, fontSize = 17.sp) },
        text = { Text(body, color = OkColors.Ink, fontFamily = OkFonts.Body, fontSize = 14.sp) },
        confirmButton = { TextButton(onClick = { onConfirm(); onDismiss() }) { Text(confirmLabel, color = OkColors.Burgundy) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = OkColors.Burgundy) } }
    )
}

@Composable
fun PlaylistPickerDialog(rows: List<PlaylistRow>, allowNone: Boolean, onPick: (PlaylistRow?) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = OkColors.Background,
        title = { Text("Choose playlist", color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontWeight = FontWeight.Bold, fontSize = 17.sp) },
        text = {
            Column(Modifier.heightIn(max = 360.dp).verticalScrollCompat()) {
                if (allowNone) TextButton(onClick = { onPick(null); onDismiss() }) { Text("None (library only)", color = OkColors.Burgundy) }
                rows.forEach { r -> TextButton(onClick = { onPick(r); onDismiss() }) { Text(r.name, color = OkColors.Burgundy) } }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = OkColors.Burgundy) } }
    )
}

private fun Modifier.verticalScrollCompat(): Modifier = composed { this.verticalScroll(androidx.compose.foundation.rememberScrollState()) }
