package com.okjaanu.app.data.scan

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Log

sealed interface ReadResult {
    data class Ok(val tags: RawTags, val art: ByteArray?) : ReadResult
    data class Failed(val reason: String) : ReadResult
}

class MetadataExtractor(private val context: Context) {
    /** Blocking; call from a background dispatcher. */
    fun read(uri: Uri): ReadResult {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            ReadResult.Ok(
                RawTags(
                    title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),
                    artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),
                    album = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM),
                    duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION),
                    track = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CD_TRACK_NUMBER)
                ),
                r.embeddedPicture
            )
        } catch (e: SecurityException) {
            Log.w(TAG, "No permission to read $uri", e)
            ReadResult.Failed("No permission to read this file.")
        } catch (e: RuntimeException) { // MediaMetadataRetriever throws RuntimeException/IllegalArgumentException for unreadable or unsupported media
            Log.w(TAG, "Cannot read metadata for $uri", e)
            ReadResult.Failed("This file could not be read as audio.")
        } finally {
            r.release()
        }
    }

    private companion object { const val TAG = "MetadataExtractor" }
}
