package com.okjaanu.app.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.okjaanu.app.ui.components.*
import com.okjaanu.app.ui.theme.*

data class NowPlayingUi(
    val title: String? = null, val artist: String? = null, val art: ImageBitmap? = null,
    val positionMs: Long = 0, val durationMs: Long = 0, val isPlaying: Boolean = false
)

fun formatTime(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return "%d:%02d".format(s / 60, s % 60) }

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NowPlayingScreen(
    ui: NowPlayingUi, onPlayPause: () -> Unit, onPrev: () -> Unit, onNext: () -> Unit, onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier, onOpenQueue: () -> Unit = {}, onToggleFavourite: () -> Unit = {}
) {
    Column(modifier.fillMaxSize().background(OkColors.Background)) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(17.dp))
            HeaderBar("Now Playing")
            Spacer(Modifier.height(28.dp))
            Box(Modifier.fillMaxWidth(), Alignment.Center) {
                Artwork(300.dp, ui.art, modifier = Modifier.combinedClickable(
                    onClick = {}, onDoubleClick = onToggleFavourite, onLongClick = onOpenQueue, onLongClickLabel = "Open queue and playback options"))
            }
            Spacer(Modifier.height(30.dp))
            Text(ui.title ?: "Nothing playing", Modifier.fillMaxWidth(), color = OkColors.Burgundy, fontFamily = OkFonts.Body,
                fontWeight = FontWeight.Bold, fontSize = 18.sp, letterSpacing = 1.5.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Text(ui.artist ?: "name of the artist", Modifier.fillMaxWidth(), color = OkColors.Burgundy, fontFamily = OkFonts.Body,
                fontSize = 14.sp, letterSpacing = 1.5.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Spacer(Modifier.height(22.dp))
            ProgressLine(if (ui.durationMs > 0) ui.positionMs.toFloat() / ui.durationMs else 0f, onSeek, Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth()) {
                Text(formatTime(ui.positionMs), color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text(formatTime(ui.durationMs), color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontSize = 12.sp)
            }
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
                Box(Modifier.size(48.dp).clickable(onClick = onPrev).semantics { contentDescription = "Previous track" }, Alignment.Center) {
                    androidx.compose.foundation.Canvas(Modifier.size(34.dp, 36.dp)) {
                        drawPath(androidx.compose.ui.graphics.Path().apply { moveTo(size.width, 0f); lineTo(0f, center.y); lineTo(size.width, size.height); close() }, OkColors.Burgundy)
                    }
                }
                RoundButton(84.dp, if (ui.isPlaying) "Pause" else "Play", onPlayPause) {
                    if (ui.isPlaying) PauseIcon(34.dp, OkColors.Background) else PlayTriangle(40.dp, OkColors.Background)
                }
                Box(Modifier.size(48.dp).clickable(onClick = onNext).semantics { contentDescription = "Next track" }, Alignment.Center) {
                    androidx.compose.foundation.Canvas(Modifier.size(34.dp, 36.dp)) {
                        drawPath(androidx.compose.ui.graphics.Path().apply { moveTo(0f, 0f); lineTo(size.width, center.y); lineTo(0f, size.height); close() }, OkColors.Burgundy)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}


@Preview(widthDp = 390, heightDp = 690)
@Composable
private fun NowPlayingPreview() = OkJaanuTheme {
    NowPlayingScreen(NowPlayingUi("Abhi Na Jao Choddkar", "name of the artist", null, 84_000, 245_000, false), {}, {}, {}, {})
}
