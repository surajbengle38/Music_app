package com.okjaanu.app.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

data class PlaylistRowEntity(val id: Long, val name: String, val songCount: Int)

@Dao
interface PlaylistDao {
    @Insert suspend fun insert(p: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :name WHERE id = :id") suspend fun rename(id: Long, name: String)

    // Cascades only to playlist_songs rows; songs and files are untouched.
    @Query("DELETE FROM playlists WHERE id = :id") suspend fun delete(id: Long)

    @Query("SELECT name FROM playlists") suspend fun allNames(): List<String>

    @Query("SELECT name FROM playlists WHERE id = :id") suspend fun nameOnce(id: Long): String?

    @Query("SELECT name FROM playlists WHERE id = :id") fun observeName(id: Long): Flow<String?>

    @Query("SELECT p.id AS id, p.name AS name, (SELECT COUNT(*) FROM playlist_songs ps WHERE ps.playlistId = p.id) AS songCount FROM playlists p ORDER BY p.createdAt, p.id")
    fun observeAll(): Flow<List<PlaylistRowEntity>>

    @Query("SELECT s.* FROM songs s INNER JOIN playlist_songs ps ON ps.songId = s.id WHERE ps.playlistId = :id ORDER BY ps.position")
    fun observeSongs(id: Long): Flow<List<SongEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addSong(e: PlaylistSongEntity): Long

    @Query("SELECT COALESCE(MAX(position), -1) FROM playlist_songs WHERE playlistId = :id") suspend fun maxPosition(id: Long): Int

    @Query("DELETE FROM playlist_songs WHERE playlistId = :pid AND songId = :sid") suspend fun removeSong(pid: Long, sid: Long)

    @Query("SELECT songId FROM playlist_songs WHERE playlistId = :id ORDER BY position") suspend fun orderedSongIds(id: Long): List<Long>

    @Query("UPDATE playlist_songs SET position = :pos WHERE playlistId = :pid AND songId = :sid") suspend fun setPosition(pid: Long, sid: Long, pos: Int)
}
