package com.okjaanu.app.playback

import android.content.Context
import android.media.audiofx.Equalizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class EqUi(
    val available: Boolean = false, val enabled: Boolean = false,
    val presets: List<String> = emptyList(), val preset: Int = -1,
    val bandHz: List<Int> = emptyList(), val levels: List<Int> = emptyList(),
    val minLevel: Int = 0, val maxLevel: Int = 0
)

/**
 * Wraps android.media.audiofx.Equalizer attached to the player's audio session (owned by PlaybackService,
 * same process). Device support varies; every call is guarded and failure turns the UI into an
 * "unavailable" state instead of crashing. Preferences persist in SharedPreferences.
 */
class EqualizerManager(context: Context) {
    private val prefs = context.getSharedPreferences("equalizer", Context.MODE_PRIVATE)
    private var eq: Equalizer? = null
    private val _state = MutableStateFlow(EqUi())
    val state: StateFlow<EqUi> = _state

    fun attach(sessionId: Int) {
        if (sessionId == 0) return // C.AUDIO_SESSION_ID_UNSET
        release()
        try {
            val e = Equalizer(0, sessionId)
            eq = e
            e.enabled = prefs.getBoolean(KEY_ENABLED, false)
            val preset = prefs.getInt(KEY_PRESET, -1)
            if (preset in 0 until e.numberOfPresets) e.usePreset(preset.toShort())
            else prefs.getString(KEY_LEVELS, null)?.split(',')?.mapNotNull { it.toIntOrNull() }
                ?.takeIf { it.size == e.numberOfBands.toInt() }?.forEachIndexed { i, l -> e.setBandLevel(i.toShort(), l.toShort()) }
            publish()
        } catch (ex: RuntimeException) { // Equalizer ctor/effects throw on unsupported devices or bad sessions
            Log.w(TAG, "Equalizer unavailable", ex)
            eq = null; _state.value = EqUi(available = false)
        }
    }

    fun release() {
        try { eq?.release() } catch (ex: RuntimeException) { Log.w(TAG, "Equalizer release failed", ex) }
        eq = null; _state.value = EqUi(available = false)
    }

    fun setEnabled(on: Boolean) = guarded { it.enabled = on; prefs.edit().putBoolean(KEY_ENABLED, on).apply() }

    fun selectPreset(i: Int) = guarded {
        it.usePreset(i.toShort())
        prefs.edit().putInt(KEY_PRESET, i).putString(KEY_LEVELS, levelsOf(it).joinToString(",")).apply()
    }

    fun setBandLevel(band: Int, level: Int) = guarded {
        it.setBandLevel(band.toShort(), level.coerceIn(it.bandLevelRange[0].toInt(), it.bandLevelRange[1].toInt()).toShort())
        prefs.edit().putInt(KEY_PRESET, -1).putString(KEY_LEVELS, levelsOf(it).joinToString(",")).apply()
    }

    private fun levelsOf(e: Equalizer) = (0 until e.numberOfBands.toInt()).map { e.getBandLevel(it.toShort()).toInt() }

    private fun guarded(block: (Equalizer) -> Unit) {
        val e = eq ?: return
        try { block(e); publish() } catch (ex: RuntimeException) {
            Log.w(TAG, "Equalizer command failed", ex); _state.value = EqUi(available = false)
        }
    }

    private fun publish() {
        val e = eq ?: return
        val range = e.bandLevelRange
        _state.value = EqUi(
            available = true, enabled = e.enabled,
            presets = (0 until e.numberOfPresets.toInt()).map { e.getPresetName(it.toShort()) },
            preset = prefs.getInt(KEY_PRESET, -1),
            bandHz = (0 until e.numberOfBands.toInt()).map { e.getCenterFreq(it.toShort()) / 1000 },
            levels = levelsOf(e), minLevel = range[0].toInt(), maxLevel = range[1].toInt()
        )
    }

    private companion object { const val TAG = "EqualizerManager"; const val KEY_ENABLED = "enabled"; const val KEY_PRESET = "preset"; const val KEY_LEVELS = "levels" }
}
