package com.okjaanu.app.data

import androidx.room.withTransaction
import com.okjaanu.app.data.db.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map

sealed interface AddToPlaylist {
    data object Added : AddToPlaylist
    data object Duplicate : AddToPlaylist
    data object Missing : AddToPlaylist // playlist or song was deleted in the meantime
}

class PlaylistRepository(private val db: AppDatabase) {
    private val dao = db.playlistDao()
    private val songs = db.songDao()

    /** Favourites first (virtual), then user playlists in creation order. */
    fun rows(): Flow<List<PlaylistRowEntity>> = combine(dao.observeAll(), songs.observeFavouriteCount()) { all, favs ->
        listOf(PlaylistRowEntity(FAVOURITES_ID, FAVOURITES_NAME, favs)) + all
    }
    fun songsOf(id: Long): Flow<List<SongEntity>> = if (id == FAVOURITES_ID) songs.observeFavourites() else dao.observeSongs(id)
    fun nameOf(id: Long): Flow<String?> = if (id == FAVOURITES_ID) flowOf(FAVOURITES_NAME) else dao.observeName(id)
    fun isFavourite(songId: Long): Flow<Boolean> = songs.observeFavourite(songId).map { it == true }

    suspend fun create(raw: String): NameCheck {
        val c = validatePlaylistName(raw, dao.allNames())
        if (c is NameCheck.Valid) dao.insert(PlaylistEntity(name = c.name, createdAt = System.currentTimeMillis()))
        return c
    }

    suspend fun rename(id: Long, raw: String): NameCheck {
        if (id == FAVOURITES_ID) return NameCheck.Reserved
        val all = dao.allNames()
        val own = dao.nameOnce(id)
        val others = if (own == null) all else all.toMutableList().also { it.remove(own) }
        val c = validatePlaylistName(raw, others)
        if (c is NameCheck.Valid) dao.rename(id, c.name)
        return c
    }

    /** Deletes the playlist only; songs stay in the library and files are never touched. */
    suspend fun delete(id: Long) { if (id != FAVOURITES_ID) dao.delete(id) }

    suspend fun addSong(playlistId: Long, songId: Long): AddToPlaylist {
        if (playlistId == FAVOURITES_ID) {
            val already = songs.isFavouriteNow(songId) == true
            songs.setFavourite(songId, true)
            return if (already) AddToPlaylist.Duplicate else AddToPlaylist.Added
        }
        return try {
            db.withTransaction {
                val r = dao.addSong(PlaylistSongEntity(playlistId = playlistId, songId = songId, position = dao.maxPosition(playlistId) + 1))
                if (r == -1L) AddToPlaylist.Duplicate else AddToPlaylist.Added
            }
        } catch (e: android.database.sqlite.SQLiteConstraintException) { // playlist or song was deleted meanwhile
            AddToPlaylist.Missing
        }
    }

    suspend fun removeSong(playlistId: Long, songId: Long) {
        if (playlistId == FAVOURITES_ID) songs.setFavourite(songId, false) else dao.removeSong(playlistId, songId)
    }

    suspend fun move(playlistId: Long, songId: Long, delta: Int) {
        if (playlistId == FAVOURITES_ID) return // favourites are sorted by title
        db.withTransaction {
            val ids = dao.orderedSongIds(playlistId)
            moved(ids, ids.indexOf(songId), delta).forEachIndexed { i, id -> dao.setPosition(playlistId, id, i) }
        }
    }

    /** Flips favourite state; returns the new state or null if the song no longer exists. */
    suspend fun toggleFavourite(songId: Long): Boolean? {
        val now = songs.isFavouriteNow(songId) ?: return null
        songs.setFavourite(songId, !now); return !now
    }
}
