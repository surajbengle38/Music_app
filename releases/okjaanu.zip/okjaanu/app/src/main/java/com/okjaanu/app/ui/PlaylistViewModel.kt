package com.okjaanu.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.okjaanu.app.OkJaanuApp
import com.okjaanu.app.data.*
import com.okjaanu.app.ui.screens.PlaylistRow
import com.okjaanu.app.ui.screens.SongRow
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class PlaylistViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as OkJaanuApp).playlists

    val rows: StateFlow<List<PlaylistRow>> = repo.rows().map { l -> l.map { PlaylistRow(it.id, it.name, it.songCount) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message
    fun clearMessage() { _message.value = null }

    fun songs(id: Long): Flow<List<SongRow>> = repo.songsOf(id).map { l -> l.map { it.toRow() } }
    fun name(id: Long): Flow<String?> = repo.nameOf(id)
    fun isFavourite(songId: Long?): Flow<Boolean> = if (songId == null) flowOf(false) else repo.isFavourite(songId)

    /** [onResult] gets a validation message, or null on success. */
    fun create(name: String, onResult: (String?) -> Unit) = viewModelScope.launch {
        val c = repo.create(name); onResult(nameProblem(c))
        if (c is NameCheck.Valid) _message.value = "Created \"${c.name}\"."
    }
    fun rename(id: Long, name: String, onResult: (String?) -> Unit) = viewModelScope.launch {
        val c = repo.rename(id, name); onResult(nameProblem(c))
        if (c is NameCheck.Valid) _message.value = "Renamed to \"${c.name}\"."
    }
    fun delete(id: Long) = viewModelScope.launch { repo.delete(id); _message.value = "Playlist deleted. Your songs are untouched." }

    fun addSong(playlistId: Long, songId: Long, playlistName: String) = viewModelScope.launch {
        _message.value = when (repo.addSong(playlistId, songId)) {
            AddToPlaylist.Added -> "Added to $playlistName."
            AddToPlaylist.Duplicate -> "Already in $playlistName."
            AddToPlaylist.Missing -> "That playlist or song no longer exists."
        }
    }
    fun removeSong(playlistId: Long, songId: Long) = viewModelScope.launch { repo.removeSong(playlistId, songId) }
    fun move(playlistId: Long, songId: Long, delta: Int) = viewModelScope.launch { repo.move(playlistId, songId, delta) }
    fun toggleFavourite(songId: Long?) {
        if (songId == null) return
        viewModelScope.launch {
            _message.value = when (repo.toggleFavourite(songId)) { true -> "Added to favourites."; false -> "Removed from favourites."; null -> "That song no longer exists." }
        }
    }
}
