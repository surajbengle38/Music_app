package com.okjaanu.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle

// Colors sampled from the supplied reference screenshots.
object OkColors {
    val Background = Color(0xFFF8F6F3)
    val Panel = Color(0xFFD9D9D9)      // header bars, cards, fields, bottom bar
    val Terracotta = Color(0xFFC4856A) // artwork placeholders
    val Burgundy = Color(0xFF7D2828)   // tabs, primary button, labels
    val Accent = Color(0xFFA33A3A)     // active tab, round buttons
    val Dashed = Color(0xFFB25C5B)
    val Heading = Color(0xFF9A6E6E)    // handwritten headings
    val Ink = Color(0xFF2B2B2B)        // card titles
    val Hint = Color(0xFF7A7A7A)       // input placeholders
}

// FONT NOTE: references use a handwritten heading face, a geometric sans (DM Sans-like)
// and a serif italic. Fonts could not be downloaded offline, so system fallbacks are used.
// To match exactly: add TTFs to res/font and replace these three values.
object OkFonts {
    val Heading: FontFamily = FontFamily.Cursive
    val Body: FontFamily = FontFamily.SansSerif
    val Serif: FontFamily = FontFamily.Serif
    val SerifItalic = FontStyle.Italic
}

@Composable
fun OkJaanuTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = OkColors.Burgundy, background = OkColors.Background,
            surface = OkColors.Background, onPrimary = OkColors.Background
        ),
        content = content
    )
}
