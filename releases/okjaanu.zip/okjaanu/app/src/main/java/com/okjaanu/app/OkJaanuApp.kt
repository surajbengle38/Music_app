package com.okjaanu.app

import android.app.Application
import androidx.room.Room
import com.okjaanu.app.data.LibraryRepository
import com.okjaanu.app.data.db.AppDatabase

/** Minimal manual DI: one database and one repository for the whole process. */
class OkJaanuApp : Application() {
    val database: AppDatabase by lazy { Room.databaseBuilder(this, AppDatabase::class.java, "okjaanu.db").addMigrations(com.okjaanu.app.data.db.MIGRATION_1_2).build() }
    val player: com.okjaanu.app.playback.PlayerController by lazy { com.okjaanu.app.playback.PlayerController(this, library) }
    val playlists: com.okjaanu.app.data.PlaylistRepository by lazy { com.okjaanu.app.data.PlaylistRepository(database) }
    val equalizer: com.okjaanu.app.playback.EqualizerManager by lazy { com.okjaanu.app.playback.EqualizerManager(this) }
    val library: LibraryRepository by lazy { LibraryRepository(this, database) }
}
