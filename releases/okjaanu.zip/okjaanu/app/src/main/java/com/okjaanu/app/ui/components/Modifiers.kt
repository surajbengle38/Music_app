package com.okjaanu.app.ui.components

import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput

fun Modifier.androidxDrawBehind(block: DrawScope.() -> Unit): Modifier = drawBehind(block)

fun Modifier.pointerInputSeek(onSeek: (Float) -> Unit): Modifier = this
    .pointerInput(Unit) { detectTapGestures { onSeek((it.x / size.width).coerceIn(0f, 1f)) } }
    .pointerInput(Unit) { detectDragGestures { c, _ -> onSeek((c.position.x / size.width).coerceIn(0f, 1f)) } }
