package com.okjaanu.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.okjaanu.app.ui.components.Artwork
import com.okjaanu.app.ui.components.HeaderBar
import com.okjaanu.app.ui.theme.OkColors
import com.okjaanu.app.ui.theme.OkFonts

/** Secondary screen (no reference supplied) in the same design language. Favourites is sorted by title, so it has no reorder buttons. */
@Composable
fun PlaylistDetailScreen(
    name: String, songs: List<SongRow>, isFavourites: Boolean,
    onPlayAll: () -> Unit, onPlaySong: (Int) -> Unit, onRemove: (SongRow) -> Unit, onMove: (SongRow, Int) -> Unit,
    onRename: () -> Unit, onDelete: () -> Unit, modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().background(OkColors.Background).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(20.dp))
        HeaderBar(name)
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionBox("PLAY", Modifier.weight(1.3f), onPlayAll)
            if (!isFavourites) { ActionBox("RENAME", Modifier.weight(1f), onRename); ActionBox("DELETE", Modifier.weight(1f), onDelete) }
        }
        Spacer(Modifier.height(20.dp))
        if (songs.isEmpty()) Text(
            if (isFavourites) "No favourites yet. Double-tap the artwork on Now Playing, or use a song's options on Home." else "This playlist is empty. Long-press a song on Home and choose \"Add to playlist\".",
            color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontSize = 15.sp
        )
        songs.forEachIndexed { i, s ->
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp).height(64.dp).background(OkColors.Panel).clickable { onPlaySong(i) }.padding(start = 12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Artwork(36.dp); Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.title, color = OkColors.Ink, fontFamily = OkFonts.Body, fontSize = 15.sp, maxLines = 1)
                    Text(s.artist, color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontSize = 12.sp, maxLines = 1)
                }
                if (!isFavourites) {
                    IconText("▲", "Move ${s.title} up", i > 0) { onMove(s, -1) }
                    IconText("▼", "Move ${s.title} down", i < songs.lastIndex) { onMove(s, 1) }
                }
                IconText("✕", "Remove ${s.title} from ${if (isFavourites) "favourites" else "playlist"}", true) { onRemove(s) }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable private fun ActionBox(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.height(48.dp).background(OkColors.Burgundy).clickable(onClick = onClick), Alignment.Center) {
        Text(label, color = OkColors.Background, fontFamily = OkFonts.Body, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 1.5.sp)
    }
}

@Composable private fun IconText(glyph: String, description: String, enabled: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier).semantics { contentDescription = description }, Alignment.Center) {
        Text(glyph, color = if (enabled) OkColors.Burgundy else OkColors.Hint, fontSize = 15.sp)
    }
}
