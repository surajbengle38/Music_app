package com.okjaanu.app.ui

import com.okjaanu.app.data.db.SongEntity
import com.okjaanu.app.ui.screens.SongRow

fun SongEntity.toRow() = SongRow(id, title, artist + if (isAvailable) "" else " (file unavailable)")
