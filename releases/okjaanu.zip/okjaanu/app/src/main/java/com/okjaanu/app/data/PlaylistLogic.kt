package com.okjaanu.app.data

const val FAVOURITES_ID = -1L          // virtual playlist backed by songs.isFavourite
const val FAVOURITES_NAME = "Favourites"

sealed interface NameCheck {
    data class Valid(val name: String) : NameCheck
    data object Empty : NameCheck
    data object TooLong : NameCheck
    data object Reserved : NameCheck
    data object Taken : NameCheck
}

/** [existing] must exclude the playlist being renamed. */
fun validatePlaylistName(raw: String, existing: Collection<String>): NameCheck {
    val n = raw.trim()
    return when {
        n.isEmpty() -> NameCheck.Empty
        n.length > 60 -> NameCheck.TooLong
        n.equals(FAVOURITES_NAME, ignoreCase = true) -> NameCheck.Reserved
        existing.any { it.equals(n, ignoreCase = true) } -> NameCheck.Taken
        else -> NameCheck.Valid(n)
    }
}

fun nameProblem(c: NameCheck): String? = when (c) {
    NameCheck.Empty -> "Give the playlist a name."
    NameCheck.TooLong -> "Name is too long (60 characters max)."
    NameCheck.Reserved -> "\"$FAVOURITES_NAME\" is built in. Pick another name."
    NameCheck.Taken -> "You already have a playlist with that name."
    is NameCheck.Valid -> null
}

/** Moves the element at [from] by [delta] places, clamped to the list. */
fun <T> moved(list: List<T>, from: Int, delta: Int): List<T> {
    if (from !in list.indices) return list
    val to = (from + delta).coerceIn(0, list.lastIndex)
    if (to == from) return list
    return list.toMutableList().also { val x = it.removeAt(from); it.add(to, x) }
}
