package com.okjaanu.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.okjaanu.app.ui.components.*
import com.okjaanu.app.ui.theme.*

data class PlaylistRow(val id: Long, val name: String, val songCount: Int)

@Composable
fun PlaylistsScreen(
    playlists: List<PlaylistRow>, current: NowPlayingUi,
    onOpen: (PlaylistRow) -> Unit, onNew: () -> Unit, onPlayPause: () -> Unit, onOpenPlayer: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().background(OkColors.Background).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(20.dp))
        HeaderBar("Playlists")
        Spacer(Modifier.height(28.dp))
        playlists.forEach { p ->
            Row(
                Modifier.fillMaxWidth().height(60.dp).background(OkColors.Panel).clickable { onOpen(p) }.padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Artwork(40.dp)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(p.name, color = OkColors.Ink, fontFamily = OkFonts.Body, fontSize = 17.sp)
                    Text(if (p.songCount == 1) "1 song" else "${p.songCount} songs", color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
        }
        DashedBox(Modifier.fillMaxWidth().height(58.dp).padding(horizontal = 20.dp), onNew) {
            PlusIcon(22.dp, OkColors.Accent, 4.dp)
            Spacer(Modifier.width(18.dp))
            Text("new playlist", color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontWeight = FontWeight.Bold, fontSize = 18.sp, letterSpacing = 1.sp)
        }
        Spacer(Modifier.height(32.dp))
        Text("current playing", Modifier.fillMaxWidth(), color = OkColors.Burgundy, fontFamily = OkFonts.Serif,
            fontStyle = OkFonts.SerifItalic, fontSize = 15.sp, textAlign = TextAlign.End)
        Spacer(Modifier.height(6.dp))
        Row(
            Modifier.fillMaxWidth().height(64.dp).background(OkColors.Panel).clickable(onClick = onOpenPlayer).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Artwork(38.dp, current.art)
            Spacer(Modifier.width(12.dp))
            Text(current.title ?: "Nothing playing", Modifier.weight(1f), color = OkColors.Burgundy, fontFamily = OkFonts.Body,
                fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 1.5.sp, maxLines = 1)
            RoundButton(36.dp, if (current.isPlaying) "Pause" else "Play", onPlayPause) {
                if (current.isPlaying) PauseIcon(14.dp, OkColors.Background) else PlayTriangle(16.dp, OkColors.Background)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Preview(widthDp = 390, heightDp = 690)
@Composable
private fun PlaylistsPreview() = OkJaanuTheme {
    PlaylistsScreen(listOf(PlaylistRow(1, "Favourites", 12), PlaylistRow(2, "Evening Ghazals", 8), PlaylistRow(3, "Road Trip", 21), PlaylistRow(4, "Old Is Gold", 34)),
        NowPlayingUi("Abhi Na Jao Choddkar"), {}, {}, {}, {})
}
