package com.okjaanu.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.okjaanu.app.playback.PlaybackUi
import com.okjaanu.app.playback.repeatLabel
import com.okjaanu.app.ui.theme.OkColors
import com.okjaanu.app.ui.theme.OkFonts

/** Secondary UI (opened by long-pressing the artwork); the Now Playing layout itself is untouched. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueSheet(
    ui: PlaybackUi, onDismiss: () -> Unit, onToggleShuffle: () -> Unit, onCycleRepeat: () -> Unit,
    onPlayIndex: (Int) -> Unit, onRemove: (Int) -> Unit,
    isFavourite: Boolean, onToggleFavourite: () -> Unit, onOpenEqualizer: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = OkColors.Background) {
        Column(Modifier.padding(horizontal = 18.dp).padding(bottom = 24.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ModeButton("shuffle: ${if (ui.shuffle) "on" else "off"}", ui.shuffle, onToggleShuffle, Modifier.weight(1f))
                ModeButton("repeat: ${repeatLabel(ui.repeatMode)}", ui.repeatMode != 0, onCycleRepeat, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ModeButton("favourite: ${if (isFavourite) "yes" else "no"}", isFavourite, onToggleFavourite, Modifier.weight(1f))
                ModeButton("equalizer", false, onOpenEqualizer, Modifier.weight(1f))
            }
            Spacer(Modifier.height(16.dp))
            Text("queue", color = OkColors.Burgundy, fontFamily = OkFonts.Serif, fontStyle = OkFonts.SerifItalic, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            if (ui.queue.isEmpty()) Text("The queue is empty. Play a song from Home to start one.", color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontSize = 14.sp)
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                itemsIndexed(ui.queue, key = { i, q -> "$i-${q.mediaId}" }) { i, q ->
                    val current = i == ui.currentIndex
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = 8.dp).height(56.dp)
                            .background(if (current) OkColors.Terracotta else OkColors.Panel)
                            .clickable { onPlayIndex(i) }.padding(start = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(q.title, color = OkColors.Ink, fontFamily = OkFonts.Body, fontSize = 15.sp, maxLines = 1,
                                fontWeight = if (current) FontWeight.Bold else FontWeight.Normal)
                            Text(q.artist, color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontSize = 12.sp, maxLines = 1)
                        }
                        Box(Modifier.size(48.dp).clickable { onRemove(i) }.semantics { contentDescription = "Remove ${q.title} from queue" }, Alignment.Center) {
                            Text("✕", color = OkColors.Burgundy, fontSize = 16.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ModeButton(label: String, active: Boolean, onClick: () -> Unit, modifier: Modifier) {
    Box(modifier.height(48.dp).background(if (active) OkColors.Accent else OkColors.Burgundy).clickable(onClick = onClick), Alignment.Center) {
        Text(label, color = OkColors.Background, fontFamily = OkFonts.Body, fontSize = 13.sp, letterSpacing = 1.sp)
    }
}

@Composable
fun SongActionsDialog(song: SongRow, onDismiss: () -> Unit, onPlay: () -> Unit, onPlayNext: () -> Unit, onAddToQueue: () -> Unit,
    onAddToPlaylist: () -> Unit, onToggleFavourite: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = OkColors.Background,
        title = { Text(song.title, color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 2) },
        text = {
            Column {
                TextButton(onClick = { onPlay(); onDismiss() }) { Text("Play", color = OkColors.Burgundy) }
                TextButton(onClick = { onPlayNext(); onDismiss() }) { Text("Play next", color = OkColors.Burgundy) }
                TextButton(onClick = { onAddToQueue(); onDismiss() }) { Text("Add to queue", color = OkColors.Burgundy) }
                TextButton(onClick = { onAddToPlaylist(); onDismiss() }) { Text("Add to playlist…", color = OkColors.Burgundy) }
                TextButton(onClick = { onToggleFavourite(); onDismiss() }) { Text("Add or remove favourite", color = OkColors.Burgundy) }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = OkColors.Burgundy) } }
    )
}
