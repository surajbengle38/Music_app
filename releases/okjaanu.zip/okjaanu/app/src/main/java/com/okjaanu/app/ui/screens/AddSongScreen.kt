package com.okjaanu.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.okjaanu.app.ui.components.*
import com.okjaanu.app.ui.theme.*

data class AddSongUi(
    val title: String = "", val artist: String = "", val playlist: String = "",
    val playlistId: Long? = null, val chosenFileName: String? = null, val art: ImageBitmap? = null, val error: String? = null
)

@Composable
fun AddSongScreen(
    ui: AddSongUi, onChooseFile: () -> Unit, onTitle: (String) -> Unit, onArtist: (String) -> Unit,
    onPickPlaylist: () -> Unit, onAdd: () -> Unit, modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().background(OkColors.Background).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(20.dp))
        HeaderBar("Add Song")
        Spacer(Modifier.height(28.dp))
        Row(Modifier.fillMaxWidth().height(96.dp)) {
            Artwork(96.dp, ui.art, "COVER ART")
            Spacer(Modifier.width(32.dp))
            DashedBox(Modifier.weight(1f).align(Alignment.CenterVertically).height(48.dp), onChooseFile) {
                Text(ui.chosenFileName ?: "choose audio file", Modifier.fillMaxWidth().padding(horizontal = 8.dp), color = OkColors.Burgundy,
                    fontFamily = OkFonts.Body, fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = 1.sp,
                    maxLines = 1, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
        Spacer(Modifier.height(24.dp))
        Label("Song name"); Field(ui.title, "e.g. Abhi Na Jao Choddkar", onTitle)
        Spacer(Modifier.height(20.dp))
        Label("Artist"); Field(ui.artist, "name of the artist", onArtist)
        Spacer(Modifier.height(20.dp))
        Label("Playlist")
        Box(Modifier.fillMaxWidth().height(48.dp).background(OkColors.Panel).clickable(onClick = onPickPlaylist).padding(horizontal = 16.dp), Alignment.CenterStart) {
            Text(ui.playlist.ifEmpty { "Favourites" }, color = if (ui.playlist.isEmpty()) OkColors.Hint else OkColors.Ink, fontFamily = OkFonts.Body, fontSize = 17.sp)
        }
        Spacer(Modifier.height(24.dp))
        Box(Modifier.fillMaxWidth().height(52.dp).background(OkColors.Burgundy).clickable(onClick = onAdd), Alignment.Center) {
            Text("ADD TO LIBRARY", color = OkColors.Background, fontFamily = OkFonts.Body, fontWeight = FontWeight.Bold, fontSize = 17.sp, letterSpacing = 2.sp)
        }
        ui.error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontSize = 13.sp) }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable private fun Label(t: String) {
    Text(t, color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 2.sp)
    Spacer(Modifier.height(8.dp))
}

@Composable private fun Field(value: String, hint: String, onChange: (String) -> Unit) {
    Box(Modifier.fillMaxWidth().height(48.dp).background(OkColors.Panel).padding(horizontal = 16.dp), Alignment.CenterStart) {
        if (value.isEmpty()) Text(hint, color = OkColors.Hint, fontFamily = OkFonts.Body, fontSize = 17.sp)
        BasicTextField(value, onChange, Modifier.fillMaxWidth(), singleLine = true, cursorBrush = SolidColor(OkColors.Burgundy),
            textStyle = TextStyle(color = OkColors.Ink, fontFamily = OkFonts.Body, fontSize = 17.sp))
    }
}

@Preview(widthDp = 390, heightDp = 690)
@Composable
private fun AddSongPreview() = OkJaanuTheme { AddSongScreen(AddSongUi(), {}, {}, {}, {}, {}) }
