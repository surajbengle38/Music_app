package com.okjaanu.app.playback

import androidx.media3.common.Player

data class QueueItem(val index: Int, val mediaId: Long, val title: String, val artist: String)

data class PlaybackUi(
    val title: String? = null, val artist: String? = null, val artPath: String? = null,
    val positionMs: Long = 0, val durationMs: Long = 0, val isPlaying: Boolean = false,
    val shuffle: Boolean = false, val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val queue: List<QueueItem> = emptyList(), val currentIndex: Int = -1, val message: String? = null, val currentId: Long? = null
)

// Pure helpers (unit-tested on the JVM).
fun nextRepeatMode(mode: Int): Int = when (mode) {
    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
    else -> Player.REPEAT_MODE_OFF
}

fun repeatLabel(mode: Int): String = when (mode) {
    Player.REPEAT_MODE_ALL -> "all"
    Player.REPEAT_MODE_ONE -> "one"
    else -> "off"
}

/** Null when the duration is not yet known (nothing to seek within). */
fun seekTargetMs(fraction: Float, durationMs: Long): Long? =
    if (durationMs <= 0) null else (fraction.coerceIn(0f, 1f) * durationMs).toLong()

fun encodeIds(ids: List<Long>): String = ids.joinToString(",")
fun decodeIds(s: String?): List<Long> = s.orEmpty().split(',').mapNotNull { it.trim().toLongOrNull() }

/**
 * A track counts as "played" once, when real playback reaches min(30s, half the track).
 * Position updates never create history by themselves; the controller records at most once per play.
 */
fun shouldCountPlay(positionMs: Long, durationMs: Long): Boolean =
    durationMs > 0 && positionMs >= minOf(30_000L, durationMs / 2)
