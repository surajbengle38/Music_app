package com.okjaanu.app.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.okjaanu.app.R
import com.okjaanu.app.ui.components.*
import com.okjaanu.app.ui.theme.*

data class SongRow(val id: Long, val title: String, val artist: String)

/** New screen (no reference supplied): reuses the same header/panel/dashed-box language. */
@Composable
fun HomeScreen(
    recentlyAdded: List<SongRow>, recentlyPlayed: List<SongRow>,
    onPlay: (List<SongRow>, Int) -> Unit, onAddMusic: () -> Unit, onScanFolder: () -> Unit, onOpenPlaylists: () -> Unit,
    modifier: Modifier = Modifier,
    query: String = "", onQuery: (String) -> Unit = {}, results: List<SongRow> = emptyList(),
    status: String? = null, scanText: String? = null, onCancelScan: () -> Unit = {},
    showRescan: Boolean = false, onRescan: () -> Unit = {}, onSongMenu: (SongRow) -> Unit = {}
) {
    Column(modifier.fillMaxSize().background(OkColors.Background).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(20.dp))
        // Logo used unedited, aspect ratio preserved (ContentScale.Fit).
        Image(painterResource(R.drawable.ok_jaanu_logo), "OK JAANU", Modifier.fillMaxWidth().height(110.dp), contentScale = ContentScale.Fit)
        Spacer(Modifier.height(20.dp))
        DashedBox(Modifier.fillMaxWidth().height(58.dp).padding(horizontal = 20.dp), onAddMusic) {
            PlusIcon(22.dp, OkColors.Accent, 4.dp); Spacer(Modifier.width(18.dp))
            Text("add music", color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontWeight = FontWeight.Bold, fontSize = 18.sp, letterSpacing = 1.sp)
        }
        Spacer(Modifier.height(12.dp))
        DashedBox(Modifier.fillMaxWidth().height(58.dp).padding(horizontal = 20.dp), onScanFolder) {
            PlusIcon(22.dp, OkColors.Accent, 4.dp); Spacer(Modifier.width(18.dp))
            Text("scan a folder", color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontWeight = FontWeight.Bold, fontSize = 18.sp, letterSpacing = 1.sp)
        }
        if (showRescan) {
            Spacer(Modifier.height(12.dp))
            DashedBox(Modifier.fillMaxWidth().height(58.dp).padding(horizontal = 20.dp), onRescan) {
                PlusIcon(22.dp, OkColors.Accent, 4.dp); Spacer(Modifier.width(18.dp))
                Text("rescan folders", color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontWeight = FontWeight.Bold, fontSize = 18.sp, letterSpacing = 1.sp)
            }
        }
        if (scanText != null) {
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(scanText, Modifier.weight(1f), color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontSize = 14.sp)
                Box(Modifier.height(40.dp).background(OkColors.Burgundy).clickable(onClick = onCancelScan).padding(horizontal = 16.dp), Alignment.Center) {
                    Text("CANCEL", color = OkColors.Background, fontFamily = OkFonts.Body, fontSize = 12.sp, letterSpacing = 1.sp)
                }
            }
        } else if (status != null) {
            Spacer(Modifier.height(12.dp))
            Text(status, color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontSize = 14.sp)
        }
        Spacer(Modifier.height(20.dp))
        Box(Modifier.fillMaxWidth().height(48.dp).background(OkColors.Panel).padding(horizontal = 16.dp), Alignment.CenterStart) {
            if (query.isEmpty()) Text("search title or artist", color = OkColors.Hint, fontFamily = OkFonts.Body, fontSize = 17.sp)
            BasicTextField(query, onQuery, Modifier.fillMaxWidth().semantics { contentDescription = "Search songs" }, singleLine = true,
                cursorBrush = SolidColor(OkColors.Burgundy), textStyle = TextStyle(color = OkColors.Ink, fontFamily = OkFonts.Body, fontSize = 17.sp))
        }
        if (query.isNotBlank()) {
            if (results.isEmpty()) { Spacer(Modifier.height(12.dp)); Text("No songs match.", color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontSize = 14.sp) }
            Section("results", results, onPlay, onSongMenu)
        } else
        if (recentlyAdded.isEmpty() && recentlyPlayed.isEmpty()) {
            Spacer(Modifier.height(32.dp))
            Text("Your library is empty. Add songs or scan a folder to get started.", color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontSize = 15.sp)
        }
        if (query.isBlank()) {
            Section("recently added", recentlyAdded, onPlay, onSongMenu)
            Section("recently played", recentlyPlayed, onPlay, onSongMenu)
        }
        Spacer(Modifier.height(16.dp))
        Box(Modifier.fillMaxWidth().height(52.dp).background(OkColors.Burgundy).clickable(onClick = onOpenPlaylists), Alignment.Center) {
            Text("OPEN PLAYLISTS", color = OkColors.Background, fontFamily = OkFonts.Body, fontWeight = FontWeight.Bold, fontSize = 16.sp, letterSpacing = 2.sp)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Section(title: String, rows: List<SongRow>, onPlay: (List<SongRow>, Int) -> Unit, onMenu: (SongRow) -> Unit) {
    if (rows.isEmpty()) return
    Spacer(Modifier.height(24.dp))
    Text(title, color = OkColors.Burgundy, fontFamily = OkFonts.Serif, fontStyle = OkFonts.SerifItalic, fontSize = 15.sp)
    Spacer(Modifier.height(6.dp))
    rows.forEachIndexed { i, s ->
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp).height(56.dp).background(OkColors.Panel).combinedClickable(onClick = { onPlay(rows, i) }, onLongClick = { onMenu(s) }, onLongClickLabel = "Song options").padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Artwork(36.dp); Spacer(Modifier.width(12.dp))
            Column { Text(s.title, color = OkColors.Ink, fontFamily = OkFonts.Body, fontSize = 15.sp, maxLines = 1); Text(s.artist, color = OkColors.Burgundy, fontFamily = OkFonts.Body, fontSize = 12.sp, maxLines = 1) }
        }
    }
}

@Preview(widthDp = 390, heightDp = 690)
@Composable
private fun HomeEmptyPreview() = OkJaanuTheme { HomeScreen(emptyList(), emptyList(), { _, _ -> }, {}, {}, {}) }
