package com.okjaanu.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.okjaanu.app.OkJaanuApp
import com.okjaanu.app.data.*
import com.okjaanu.app.data.db.SongEntity
import com.okjaanu.app.ui.screens.AddSongUi
import com.okjaanu.app.ui.screens.SongRow
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
class LibraryViewModel(app: Application) : AndroidViewModel(app) {
    private val okApp = app as OkJaanuApp
    private val repo = okApp.library
    private val playlists = okApp.playlists
    private var pendingUri: Uri? = null
    private var pendingArtBytes: ByteArray? = null
    private var scanJob: Job? = null

    private val _addUi = MutableStateFlow(AddSongUi())
    val addUi: StateFlow<AddSongUi> = _addUi
    private val _status = MutableStateFlow<String?>(null)
    val status: StateFlow<String?> = _status
    private val _scanning = MutableStateFlow<ScanProgress?>(null)
    val scanning: StateFlow<ScanProgress?> = _scanning
    val query = MutableStateFlow("")

    val recentlyAdded: StateFlow<List<SongRow>> = repo.recentlyAdded().map { it.map { s -> s.toRow() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val results: StateFlow<List<SongRow>> = query.debounce(150).distinctUntilChanged()
        .flatMapLatest { q -> if (q.isBlank()) flowOf(emptyList()) else repo.search(q).map { it.map { s -> s.toRow() } } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val recentlyPlayed: StateFlow<List<SongRow>> = repo.recentlyPlayed().map { it.map { s -> s.toRow() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val hasFolders: StateFlow<Boolean> = repo.rootCount().map { it > 0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)


    fun setPlaylist(id: Long?, name: String) = _addUi.update { it.copy(playlistId = id, playlist = name, error = null) }
    fun setTitle(t: String) = _addUi.update { it.copy(title = t, error = null) }
    fun setArtist(a: String) = _addUi.update { it.copy(artist = a, error = null) }
    fun setQuery(q: String) { query.value = q }

    fun onFilePicked(uri: Uri?) {
        if (uri == null) { _addUi.update { it.copy(error = "No file selected.") }; return } // picker cancelled
        viewModelScope.launch {
            repo.preview(uri).fold(
                onSuccess = { p ->
                    pendingUri = uri; pendingArtBytes = p.art
                    _addUi.value = AddSongUi(title = p.meta.title, artist = p.meta.artist, playlist = _addUi.value.playlist, playlistId = _addUi.value.playlistId,
                        chosenFileName = p.displayName, art = p.art?.let { decodeSampled(it) })
                },
                onFailure = { e -> _addUi.update { it.copy(error = e.message ?: "Could not read this file.") } }
            )
        }
    }

    fun addToLibrary() {
        val uri = pendingUri
        val ui = _addUi.value
        if (uri == null) { _addUi.update { it.copy(error = "Choose an audio file first.") }; return }
        if (ui.title.isBlank()) { _addUi.update { it.copy(error = "Song name can't be empty.") }; return }
        viewModelScope.launch {
            when (val r = repo.importUri(uri, ui.title, ui.artist)) {
                is AddOutcome.Added -> {
                    val note = ui.playlistId?.let { pid ->
                        when (playlists.addSong(pid, r.id)) {
                            AddToPlaylist.Added -> " and to ${ui.playlist}"
                            AddToPlaylist.Duplicate -> " (already in ${ui.playlist})"
                            AddToPlaylist.Missing -> " (that playlist no longer exists)"
                        }
                    }.orEmpty()
                    _addUi.value = AddSongUi(); pendingUri = null
                    _status.value = "Added \"${ui.title.trim()}\" to your library$note."
                }
                AddOutcome.Duplicate -> _addUi.update { it.copy(error = "This file is already in your library.") }
                is AddOutcome.Unsupported -> _addUi.update { it.copy(error = r.reason) }
            }
        }
    }

    fun scanFolder(uri: Uri?) {
        if (uri == null) { _status.value = "No folder selected."; return }
        runScan { repo.scanTree(uri, ::publish) }
    }

    fun rescan() = runScan { repo.rescanAll(::publish) }
    fun cancelScan() { scanJob?.cancel() }
    fun clearStatus() { _status.value = null }

    private fun publish(p: ScanProgress) { _scanning.value = p }

    private fun runScan(block: suspend () -> ScanSummary) {
        if (scanJob?.isActive == true) { _status.value = "A scan is already running."; return }
        scanJob = viewModelScope.launch {
            _scanning.value = ScanProgress(); _status.value = null
            try {
                val s = block()
                _status.value = s.error ?: "Scan complete: ${s.progress.added} added, ${s.progress.skipped} already indexed, ${s.progress.unsupported} unsupported."
            } catch (e: CancellationException) {
                _status.value = "Scan cancelled. Songs found so far were kept."
                throw e
            } finally { _scanning.value = null }
        }
    }
}
