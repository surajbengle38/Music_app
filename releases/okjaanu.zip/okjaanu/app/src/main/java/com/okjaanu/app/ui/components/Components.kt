package com.okjaanu.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.okjaanu.app.ui.theme.OkColors
import com.okjaanu.app.ui.theme.OkFonts

enum class Tab { Home, Playlists, Player, None }

@Composable
fun HeaderBar(title: String) {
    Box(
        Modifier.fillMaxWidth().height(64.dp).background(OkColors.Panel).padding(start = 22.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(title.uppercase(), color = OkColors.Heading, fontFamily = OkFonts.Heading, fontSize = 40.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(end = 12.dp))
    }
}

/** Square artwork box; shows real artwork when supplied, else the terracotta placeholder. */
@Composable
fun Artwork(size: androidx.compose.ui.unit.Dp, art: ImageBitmap? = null, label: String? = null, modifier: Modifier = Modifier) {
    Box(modifier.size(size).background(OkColors.Terracotta), contentAlignment = Alignment.Center) {
        if (art != null) Image(art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else if (label != null) Text(label, color = OkColors.Background, fontFamily = OkFonts.Body, fontSize = 14.sp, letterSpacing = 1.sp)
    }
}

@Composable
fun RoundButton(size: androidx.compose.ui.unit.Dp, description: String, onClick: () -> Unit, content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier.size(size).clip(CircleShape).background(OkColors.Accent)
            .clickable(onClick = onClick).semantics { contentDescription = description },
        contentAlignment = Alignment.Center, content = content
    )
}

@Composable
fun PlusIcon(size: androidx.compose.ui.unit.Dp, color: Color, stroke: androidx.compose.ui.unit.Dp) {
    Canvas(Modifier.size(size)) {
        val s = stroke.toPx(); val c = center
        drawLine(color, Offset(0f, c.y), Offset(this.size.width, c.y), s)
        drawLine(color, Offset(c.x, 0f), Offset(c.x, this.size.height), s)
    }
}

@Composable
fun PlayTriangle(size: androidx.compose.ui.unit.Dp, color: Color) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        drawPath(Path().apply { moveTo(w * 0.15f, 0f); lineTo(w, h / 2f); lineTo(w * 0.15f, h); close() }, color)
    }
}

@Composable
fun PauseIcon(size: androidx.compose.ui.unit.Dp, color: Color) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width * 0.28f
        drawRect(color, Offset(this.size.width * 0.12f, 0f), Size(w, this.size.height))
        drawRect(color, Offset(this.size.width * 0.60f, 0f), Size(w, this.size.height))
    }
}

/** Bottom bar: Home / Playlists / Player tabs plus circular "+" (opens Add Song). */
@Composable
fun BottomBar(active: Tab, onTab: (Tab) -> Unit, onPlus: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(70.dp).background(OkColors.Panel).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        listOf(Tab.Home to "Home", Tab.Playlists to "Playlists", Tab.Player to "Player").forEach { (t, label) ->
            Box(
                Modifier.padding(end = 10.dp).weight(1f).height(48.dp)
                    .background(if (t == active) OkColors.Accent else OkColors.Burgundy)
                    .clickable { onTab(t) },
                contentAlignment = Alignment.Center
            ) { Text(label, color = OkColors.Background, fontFamily = OkFonts.Body, fontSize = 13.sp) }
        }
        Spacer(Modifier.weight(0.45f))
        RoundButton(50.dp, "Add song", onPlus) { PlusIcon(22.dp, OkColors.Background, 4.dp) }
    }
}

@Composable
fun DashedBox(modifier: Modifier = Modifier, onClick: () -> Unit, content: @Composable RowScope.() -> Unit) {
    Row(
        modifier.clickable(onClick = onClick).drawDashedBorder(),
        verticalAlignment = Alignment.CenterVertically, content = content
    )
}

private fun Modifier.drawDashedBorder(): Modifier = this.then(
    Modifier.androidxDrawBehind {
        drawRect(OkColors.Dashed, style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(8.dp.toPx(), 5.dp.toPx()))))
    }
)

/** Thin line with arrowhead; burgundy portion shows real progress; taps/drags request a seek. */
@Composable
fun ProgressLine(fraction: Float, onSeek: (Float) -> Unit, modifier: Modifier = Modifier) {
    Canvas(
        modifier.height(24.dp).semantics { contentDescription = "Playback position" }
            .pointerInputSeek(onSeek)
    ) {
        val y = size.height / 2; val sw = 1.5.dp.toPx(); val head = 8.dp.toPx()
        drawLine(OkColors.Ink, Offset(0f, y), Offset(size.width, y), sw)
        drawLine(OkColors.Accent, Offset(0f, y), Offset(size.width * fraction.coerceIn(0f, 1f), y), sw * 2, StrokeCap.Butt)
        drawLine(OkColors.Ink, Offset(size.width - head, y - head / 1.4f), Offset(size.width, y), sw)
        drawLine(OkColors.Ink, Offset(size.width - head, y + head / 1.4f), Offset(size.width, y), sw)
    }
}
