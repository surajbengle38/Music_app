package com.okjaanu.app.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Identity strategy: the SAF document URI string is the unique key. A given file at a given
 * indexed location always yields the same URI, so rescans cannot create duplicates. File names
 * are NOT used for identity. Moved files get a new URI and appear as new entries; the old
 * record is only flagged unavailable, never deleted (playlists/history are preserved).
 */
@Entity(tableName = "songs", indices = [Index(value = ["uri"], unique = true)])
data class SongEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val title: String,
    val artist: String,
    val album: String?,
    val durationMs: Long,
    val trackNumber: Int?,
    val artPath: String?,
    val sizeBytes: Long?,
    val isFavourite: Boolean = false,
    val isAvailable: Boolean = true,
    val addedAt: Long
)

/** Folder trees the user granted, kept so the library can be rescanned on request. */
@Entity(tableName = "library_roots")
data class LibraryRootEntity(@PrimaryKey val treeUri: String, val addedAt: Long)

@Entity(tableName = "playlists")
data class PlaylistEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val createdAt: Long)

/** Ordered membership. A song appears at most once per playlist (unique index); removing it here never touches the library. */
@Entity(
    tableName = "playlist_songs",
    foreignKeys = [
        ForeignKey(entity = PlaylistEntity::class, parentColumns = ["id"], childColumns = ["playlistId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = SongEntity::class, parentColumns = ["id"], childColumns = ["songId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index(value = ["playlistId", "songId"], unique = true), Index(value = ["songId"])]
)
data class PlaylistSongEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long, val songId: Long, val position: Int
)

@Entity(
    tableName = "history",
    foreignKeys = [ForeignKey(entity = SongEntity::class, parentColumns = ["id"], childColumns = ["songId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["songId"])]
)
data class HistoryEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val songId: Long, val playedAt: Long)
