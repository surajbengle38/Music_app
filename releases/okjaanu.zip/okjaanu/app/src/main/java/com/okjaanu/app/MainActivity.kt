package com.okjaanu.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.okjaanu.app.ui.OkJaanuRoot
import com.okjaanu.app.ui.theme.OkJaanuTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OkJaanuTheme { OkJaanuRoot() } }
    }
}
