package com.okjaanu.app.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.okjaanu.app.data.LibraryRepository
import com.okjaanu.app.data.db.SongEntity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.guava.await
import java.io.File

/** UI-side handle to the playback service. Every value in [state] is read from the real player. */
class PlayerController(private val context: Context, private val library: LibraryRepository) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val prefs = context.getSharedPreferences("playback_session", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(PlaybackUi())
    val state: StateFlow<PlaybackUi> = _state
    private var connection: Deferred<MediaController>? = null
    private var started = false
    private var pollJob: Job? = null
    private var countedId: Long? = null // song already recorded for the current play

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            refresh(player)
            if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION)) countedId = null // new item or repeat-one loop = new play
            if (events.contains(Player.EVENT_IS_PLAYING_CHANGED)) updatePolling(player)
            if (events.containsAny(Player.EVENT_MEDIA_ITEM_TRANSITION, Player.EVENT_TIMELINE_CHANGED) ||
                (events.contains(Player.EVENT_IS_PLAYING_CHANGED) && !player.isPlaying)) persist(player)
        }
        override fun onPlayerError(error: PlaybackException) {
            val msg = "A song couldn't be played (missing or unreadable file)."
            _state.update { it.copy(message = msg) }
        }
    }

    fun start() {
        if (started) return
        started = true
        run { c -> c.addListener(listener); refresh(c); updatePolling(c); restoreIfEmpty(c) }
    }

    private suspend fun controller(): MediaController {
        val d = connection ?: scope.async {
            val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
            MediaController.Builder(context, token).buildAsync().await()
        }.also { connection = it }
        return d.await()
    }

    private fun run(block: suspend (MediaController) -> Unit) {
        scope.launch {
            try {
                block(controller())
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) { // connection or player-command failure: surface instead of crashing
                Log.e(TAG, "Playback command failed", e)
                connection = null
                _state.update { it.copy(message = "Playback is unavailable right now.") }
            }
        }
    }

    // ----- commands -----
    fun playList(songs: List<SongEntity>, startIndex: Int) = run { c ->
        if (songs.isEmpty()) return@run
        c.setMediaItems(songs.map(::toItem), startIndex.coerceIn(0, songs.lastIndex), 0L)
        c.prepare(); c.play()
    }
    fun playNext(song: SongEntity) = run { c ->
        if (c.mediaItemCount == 0) { c.setMediaItem(toItem(song)); c.prepare(); c.play() }
        else c.addMediaItem(c.currentMediaItemIndex + 1, toItem(song))
    }
    fun addToQueue(song: SongEntity) = run { c ->
        if (c.mediaItemCount == 0) { c.setMediaItem(toItem(song)); c.prepare(); c.play() } else c.addMediaItem(toItem(song))
    }
    fun playQueueIndex(i: Int) = run { c -> if (i in 0 until c.mediaItemCount) { c.seekTo(i, 0L); c.prepare(); c.play() } }
    fun removeFromQueue(i: Int) = run { c -> if (i in 0 until c.mediaItemCount) c.removeMediaItem(i) }
    fun togglePlayPause() = run { c ->
        if (c.mediaItemCount == 0) return@run
        if (c.isPlaying) c.pause() else {
            if (c.playbackState == Player.STATE_ENDED) c.seekToDefaultPosition(0)
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            c.play()
        }
    }
    fun next() = run { it.seekToNext() }
    fun previous() = run { it.seekToPrevious() } // >3s into a track restarts it, otherwise previous track (Media3 default)
    fun seekToFraction(f: Float) = run { c -> seekTargetMs(f, c.duration.takeIf { it != C.TIME_UNSET } ?: 0L)?.let { c.seekTo(it) } }
    fun toggleShuffle() = run { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    fun cycleRepeat() = run { it.repeatMode = nextRepeatMode(it.repeatMode) }
    fun clearMessage() { _state.update { it.copy(message = null) } }

    // ----- state -----
    private fun refresh(p: Player) {
        val queue = (0 until p.mediaItemCount).map { i ->
            val item = p.getMediaItemAt(i)
            QueueItem(i, item.mediaId.toLongOrNull() ?: -1, item.mediaMetadata.title?.toString().orEmpty(), item.mediaMetadata.artist?.toString().orEmpty())
        }
        val cur = p.currentMediaItem
        _state.update {
            it.copy(
                title = cur?.mediaMetadata?.title?.toString(), artist = cur?.mediaMetadata?.artist?.toString(),
                artPath = cur?.mediaMetadata?.artworkUri?.path,
                positionMs = p.currentPosition.coerceAtLeast(0),
                durationMs = p.duration.takeIf { d -> d != C.TIME_UNSET } ?: 0L,
                isPlaying = p.isPlaying || (p.playWhenReady && p.playbackState == Player.STATE_BUFFERING),
                shuffle = p.shuffleModeEnabled, repeatMode = p.repeatMode,
                queue = queue, currentIndex = if (cur == null) -1 else p.currentMediaItemIndex,
                currentId = cur?.mediaId?.toLongOrNull()
            )
        }
    }

    // Real position polled from the player while it plays (no simulated timer progress).
    private fun updatePolling(p: Player) {
        pollJob?.cancel()
        if (!p.isPlaying) return
        pollJob = scope.launch {
            while (isActive) {
                _state.update { it.copy(positionMs = p.currentPosition.coerceAtLeast(0)) }
                val id = p.currentMediaItem?.mediaId?.toLongOrNull()
                if (id != null && id != countedId && shouldCountPlay(p.currentPosition, p.duration.takeIf { it != C.TIME_UNSET } ?: 0L)) {
                    countedId = id
                    scope.launch {
                        try { library.recordPlay(id) } catch (e: android.database.sqlite.SQLiteException) { Log.w(TAG, "Could not record history", e) }
                    }
                }
                delay(500)
            }
        }
    }

    // ----- session persistence (queue ids, index, position) -----
    private fun persist(p: Player) {
        val ids = (0 until p.mediaItemCount).mapNotNull { p.getMediaItemAt(it).mediaId.toLongOrNull() }
        prefs.edit()
            .putString(KEY_IDS, encodeIds(ids)).putLong(KEY_CURRENT, p.currentMediaItem?.mediaId?.toLongOrNull() ?: -1)
            .putLong(KEY_POS, p.currentPosition.coerceAtLeast(0)).apply()
    }

    private suspend fun restoreIfEmpty(c: MediaController) {
        if (c.mediaItemCount > 0) return // service still alive with its own queue
        val ids = decodeIds(prefs.getString(KEY_IDS, null)); if (ids.isEmpty()) return
        val songs = library.songsByIds(ids); if (songs.isEmpty()) return
        val idx = songs.indexOfFirst { it.id == prefs.getLong(KEY_CURRENT, -1) }.coerceAtLeast(0)
        c.setMediaItems(songs.map(::toItem), idx, prefs.getLong(KEY_POS, 0L))
        c.prepare() // paused; the user presses play
    }

    private fun toItem(s: SongEntity): MediaItem = MediaItem.Builder()
        .setMediaId(s.id.toString()).setUri(Uri.parse(s.uri))
        .setMediaMetadata(
            MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).setAlbumTitle(s.album)
                .setArtworkUri(s.artPath?.let { Uri.fromFile(File(it)) }).build()
        ).build()

    private companion object {
        const val TAG = "PlayerController"; const val KEY_IDS = "ids"; const val KEY_CURRENT = "current"; const val KEY_POS = "pos"
    }
}
