package com.okjaanu.app

import androidx.media3.common.Player
import com.okjaanu.app.playback.*
import com.okjaanu.app.ui.screens.formatTime
import org.junit.Assert.*
import org.junit.Test

class PlaybackLogicTest {
    @Test fun repeatCycles() {
        assertEquals(Player.REPEAT_MODE_ALL, nextRepeatMode(Player.REPEAT_MODE_OFF))
        assertEquals(Player.REPEAT_MODE_ONE, nextRepeatMode(Player.REPEAT_MODE_ALL))
        assertEquals(Player.REPEAT_MODE_OFF, nextRepeatMode(Player.REPEAT_MODE_ONE))
    }
    @Test fun seekTarget() {
        assertNull(seekTargetMs(0.5f, 0)); assertEquals(50_000L, seekTargetMs(0.5f, 100_000)); assertEquals(100_000L, seekTargetMs(2f, 100_000)); assertEquals(0L, seekTargetMs(-1f, 100_000))
    }
    @Test fun idsRoundTrip() {
        assertEquals(listOf(3L, 1L, 2L), decodeIds(encodeIds(listOf(3, 1, 2)))); assertEquals(emptyList<Long>(), decodeIds(null)); assertEquals(listOf(5L), decodeIds("x,5,"))
    }
    @Test fun timeFormat() { assertEquals("1:24", formatTime(84_000)); assertEquals("0:00", formatTime(-5)); assertEquals("4:05", formatTime(245_999)) }
}
