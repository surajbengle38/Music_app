package com.okjaanu.app

import com.okjaanu.app.data.scan.*
import org.junit.Assert.*
import org.junit.Test

class TagMapperTest {
    @Test fun usesTagsWhenPresent() {
        val m = TagMapper.map(RawTags(" Song ", "Artist", "Album", "245000", "3/12"), "x.mp3")
        assertEquals("Song", m.title); assertEquals("Artist", m.artist); assertEquals(245000L, m.durationMs); assertEquals(3, m.trackNumber)
    }
    @Test fun fallsBackToFileNameAndUnknownArtist() {
        val m = TagMapper.map(RawTags(null, "  ", null, null, null), "My Song.final.flac")
        assertEquals("My Song.final", m.title); assertEquals(UNKNOWN_ARTIST, m.artist); assertNull(m.durationMs); assertNull(m.trackNumber)
    }
    @Test fun rejectsZeroDurationAndBadTrack() {
        val m = TagMapper.map(RawTags("a", "b", null, "0", "x"), "a.ogg")
        assertNull(m.durationMs); assertNull(m.trackNumber)
    }
    @Test fun supportedExtensions() {
        assertTrue(isSupportedAudioName("a.MP3")); assertTrue(isSupportedAudioName("a.m4a")); assertFalse(isSupportedAudioName("a.wma")); assertFalse(isSupportedAudioName("noext"))
    }
    @Test fun escapesLikeWildcards() { assertEquals("100\\%\\_\\\\", escapeLike("100%_\\")) }
}
