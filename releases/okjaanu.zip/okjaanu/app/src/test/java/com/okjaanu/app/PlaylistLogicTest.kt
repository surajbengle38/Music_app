package com.okjaanu.app

import com.okjaanu.app.data.*
import com.okjaanu.app.playback.shouldCountPlay
import org.junit.Assert.*
import org.junit.Test

class PlaylistLogicTest {
    @Test fun nameValidation() {
        assertEquals(NameCheck.Empty, validatePlaylistName("   ", emptyList()))
        assertEquals(NameCheck.Reserved, validatePlaylistName("favourites", emptyList()))
        assertEquals(NameCheck.Taken, validatePlaylistName(" road TRIP ", listOf("Road Trip")))
        assertEquals(NameCheck.TooLong, validatePlaylistName("x".repeat(61), emptyList()))
        assertEquals(NameCheck.Valid("Jazz"), validatePlaylistName(" Jazz ", listOf("Road Trip")))
    }
    @Test fun moveClampsAndReorders() {
        assertEquals(listOf(2, 1, 3), moved(listOf(1, 2, 3), 1, -1))
        assertEquals(listOf(1, 3, 2), moved(listOf(1, 2, 3), 1, 1))
        assertEquals(listOf(1, 2, 3), moved(listOf(1, 2, 3), 0, -1))
        assertEquals(listOf(1, 2, 3), moved(listOf(1, 2, 3), 5, 1))
    }
    @Test fun playCountThreshold() {
        assertFalse(shouldCountPlay(29_999, 200_000)); assertTrue(shouldCountPlay(30_000, 200_000))
        assertFalse(shouldCountPlay(5_000, 20_000)); assertTrue(shouldCountPlay(10_000, 20_000)); assertFalse(shouldCountPlay(50_000, 0))
    }
}
